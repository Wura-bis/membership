﻿import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import MainLayout from "../../components/mainlayout";
import DeactivateConfirm from "../../components/deactivateconfirm";
import { useAuth } from "../../hooks/useauth";
import { API_BASE_URL } from '../../utils/api';

export default function Members() {
  const { user } = useAuth();
  const [members, setMembers] = useState([]);
  
  // Initialize from sessionStorage with defaults
  const [search, setSearch] = useState(() => sessionStorage.getItem('memberSearch') || "");
  const [roleFilter, setRoleFilter] = useState(() => sessionStorage.getItem('memberRoleFilter') || "all");
  const [roleOptions, setRoleOptions] = useState([]);
  const [categoryFilter, setCategoryFilter] = useState(() => sessionStorage.getItem('memberCategoryFilter') || "all");
  const [countyFilter, setCountyFilter] = useState(() => sessionStorage.getItem('memberCountyFilter') || "all");
  const [volunteeringFilter, setVolunteeringFilter] = useState(() => sessionStorage.getItem('memberVolunteeringFilter') || "all");
  const [volunteeringOptions, setVolunteeringOptions] = useState([]);
  const [sortBy, setSortBy] = useState(() => sessionStorage.getItem('memberSortBy') || "lastName");
  const [sortOrder, setSortOrder] = useState(() => sessionStorage.getItem('memberSortOrder') || "asc");
  const [error, setError] = useState("");
  const [selectedMember, setSelectedMember] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [mergeMode, setMergeMode] = useState(false);
  const [mergePrimary, setMergePrimary] = useState(null);
  const [mergeSecondary, setMergeSecondary] = useState(null);
  const [mergeSearchPrimary, setMergeSearchPrimary] = useState("");
  const [mergeSearchSecondary, setMergeSearchSecondary] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [countyOptions, setCountyOptions] = useState([]);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  // Bulk selection state
  const [selectedMembers, setSelectedMembers] = useState(new Set());
  const [selectAll, setSelectAll] = useState(false);
  const [bulkExportLoading, setBulkExportLoading] = useState(false);
  const [bulkDeactivateLoading, setBulkDeactivateLoading] = useState(false);

  // Persist search filters to sessionStorage whenever they change
  useEffect(() => {
    sessionStorage.setItem('memberSearch', search);
  }, [search]);

  useEffect(() => {
    sessionStorage.setItem('memberRoleFilter', roleFilter);
  }, [roleFilter]);

  useEffect(() => {
    sessionStorage.setItem('memberCategoryFilter', categoryFilter);
  }, [categoryFilter]);

  useEffect(() => {
    sessionStorage.setItem('memberCountyFilter', countyFilter);
  }, [countyFilter]);

  useEffect(() => {
    sessionStorage.setItem('memberVolunteeringFilter', volunteeringFilter);
  }, [volunteeringFilter]);

  useEffect(() => {
    sessionStorage.setItem('memberSortBy', sortBy);
  }, [sortBy]);

  useEffect(() => {
    sessionStorage.setItem('memberSortOrder', sortOrder);
  }, [sortOrder]);

  // Remove forced redirect for public users

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/members?sortBy=${sortBy}&sortOrder=${sortOrder}`, {
      credentials: "include",
    })
      .then((res) => res.json())
      .then((data) => {
        setMembers(Array.isArray(data) ? data : []);
        if (Array.isArray(data)) {
          const allInterests = [...new Set(data.flatMap(m => m.volunteeringInterests || []))].sort();
          setVolunteeringOptions(allInterests);
          const allRoles = [...new Set(data.map(m => m.role).filter(Boolean))].sort();
          setRoleOptions(allRoles);
        }
        if (!Array.isArray(data) && data.error) setError(data.error);
        setIsLoading(false);
      })
      .catch(() => {
        setError("Failed to load members");
        setIsLoading(false);
      });
  }, [sortBy, sortOrder]);

  const handleConfirmDeactivate = async () => {
    if (!selectedMember) return;
    try {
      const res = await fetch(
        `${API_BASE_URL}/api/members/${selectedMember.id}/deactivate`,
        { method: "POST", credentials: "include" }
      );
      const data = await res.json();
      if (data.success) {
        alert("Member deactivated.");
        setMembers((prev) =>
          prev.map((m) =>
            m.id === selectedMember.id ? { ...m, isActive: false } : m
          )
        );
      } else {
        alert("Failed to deactivate: " + data.message);
      }
    } catch {
      alert("Error deactivating member.");
    } finally {
      setSelectedMember(null);
      setShowConfirm(false);
    }
  };

  const handleMergeMembers = async () => {
    if (!mergePrimary || !mergeSecondary) return;
    if (mergePrimary.id === mergeSecondary.id) {
      alert("Please select two different members to merge.");
      return;
    }
    if (!window.confirm(`Merge ${mergeSecondary.firstName} ${mergeSecondary.lastName} into ${mergePrimary.firstName} ${mergePrimary.lastName}? This will delete the secondary record and cannot be undone.`)) return;

    try {
      const res = await fetch(
        `${API_BASE_URL}/api/members/merge`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            primaryMemberId: mergePrimary.id,
            secondaryMemberId: mergeSecondary.id,
            keepData: "primary"
          })
        }
      );
      const data = await res.json();
      if (data.success) {
        alert(data.message || "Members merged successfully!");
        setMembers((prev) => prev.filter(m => m.id !== mergeSecondary.id));
        setMergeMode(false);
        setMergePrimary(null);
        setMergeSecondary(null);
        setMergeSearchPrimary("");
        setMergeSearchSecondary("");
      } else {
        alert("Failed to merge: " + data.message);
      }
    } catch {
      alert("Error merging members.");
    }
  };

  // Bulk selection handlers
  const handleMemberSelect = (memberId) => {
    const newSelected = new Set(selectedMembers);
    if (newSelected.has(memberId)) {
      newSelected.delete(memberId);
    } else {
      newSelected.add(memberId);
    }
    setSelectedMembers(newSelected);
    setSelectAll(false);
  };

  const handleSelectAllChange = () => {
    if (selectAll) {
      setSelectedMembers(new Set());
      setSelectAll(false);
    } else {
      const allIds = new Set(paginatedMembers.map(m => m.id));
      setSelectedMembers(allIds);
      setSelectAll(true);
    }
  };

  const handleBulkExport = async () => {
    if (selectedMembers.size === 0) {
      alert("Please select members to export.");
      return;
    }
    try {
      setBulkExportLoading(true);
      const memberIds = Array.from(selectedMembers);
      const res = await fetch(`${API_BASE_URL}/api/export/members/csv`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ ids: memberIds })
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => null);
        alert(`Export failed: ${res.status} ${res.statusText}${txt ? '\n' + txt : ''}`);
        return;
      }
      const blob = await res.blob();
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `members_export_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(link.href);
    } catch {
      alert("Failed to export selected members.");
    } finally {
      setBulkExportLoading(false);
    }
  };

  const handleBulkDeactivate = async () => {
    if (selectedMembers.size === 0) {
      alert("Please select members to deactivate.");
      return;
    }
    if (!window.confirm(`Deactivate ${selectedMembers.size} member(s)? This action can be reversed.`)) {
      return;
    }
    try {
      setBulkDeactivateLoading(true);
      const memberIds = Array.from(selectedMembers);
      const res = await fetch(`${API_BASE_URL}/api/members/bulk-deactivate`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberIds })
      });
      const data = await res.json();
      if (data.success) {
        alert(`Deactivated ${selectedMembers.size} member(s).`);
        setMembers((prev) =>
          prev.map((m) =>
            selectedMembers.has(m.id) ? { ...m, isActive: false } : m
          )
        );
        setSelectedMembers(new Set());
        setSelectAll(false);
      } else {
        alert("Failed to deactivate members: " + data.message);
      }
    } catch {
      alert("Error deactivating members.");
    } finally {
      setBulkDeactivateLoading(false);
    }
  };

  // Remove the client-side sorting since backend now handles it
  // Just return filtered members directly

  // Updated filter logic (backend now handles sorting)
  const filtered = members.filter((m) => {
    // Role-based filtering: Admin sees ALL members, others see backend-filtered results
    // The backend already handles role-based filtering, so don't filter by isActive here
    
    const libraryEmail = 'bisofpeilibrary@gmail.com';
    const matchesSearch = [
      m.firstName, m.lastName, m.address, m.addressSearch, m.role,
      m.placeOfBirth, m.dateOfBirth, m.category, m.dateJoined, m.dateEnded,
      m.email !== libraryEmail ? m.email : '',
      m.phoneNumber,
      m.approvedBy, m.signedBy, m.proposer, m.seconder,
      m.occupation, m.otherSocieties, m.notes,
      ...(m.volunteeringInterests || []),
      ...(m.irishSurnames || []),
      ...(m.allPhones || []),
      ...(m.allCounties || [])
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesRole =
      roleFilter === "all" || m.role === roleFilter;

    const matchesCategory =
      categoryFilter === "all" || m.category === categoryFilter;

    const matchesCounty =
      countyFilter === "all" || (m.allCounties || [m.county]).includes(countyFilter);

    const matchesVolunteering =
      volunteeringFilter === "all" || (m.volunteeringInterests || []).includes(volunteeringFilter);

    return matchesSearch && matchesRole && matchesCategory && matchesCounty && matchesVolunteering;
  });

  // Pagination calculation
  const totalPages = Math.ceil(filtered.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedMembers = filtered.slice(startIndex, endIndex);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [search, roleFilter, categoryFilter, countyFilter, volunteeringFilter, sortBy, sortOrder]);

  // Helper function to handle column header clicks
  const handleSort = (column) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("asc");
    }
  };

  // Helper function to render sortable column header
  const SortableHeader = ({ column, children }) => {
    const isActive = sortBy === column;
    const columnStyle = {};
    if (column === 'dateJoined' || column === 'category') {
      columnStyle.minWidth = '140px';
    }
    if (column === 'lastName') {
      columnStyle.minWidth = '140px';
    }
    return (
      <th 
        style={{ 
          padding: '20px', 
          textAlign: 'left',
          fontWeight: '700',
          color: isActive ? '#14b8a6' : '#0f766e',
          fontSize: '16px',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          cursor: 'pointer',
          userSelect: 'none',
          position: 'relative',
          transition: 'color 0.2s ease',
          background: isActive ? '#e0f2fe' : 'transparent',
          ...columnStyle
        }}
        onClick={() => handleSort(column)}
        onMouseEnter={(e) => {
          if (!isActive) e.target.style.color = '#14b8a6';
        }}
        onMouseLeave={(e) => {
          if (!isActive) e.target.style.color = '#0f766e';
        }}
        title={`Sort by ${children}${isActive ? ` (currently ${sortOrder === "asc" ? "A-Z" : "Z-A"})` : ""}`}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {children}
          {isActive ? (
            <span style={{ 
              fontSize: '18px', 
              fontWeight: 'bold',
              color: '#14b8a6'
            }}>
              {sortOrder === "asc" ? "↑" : "↓"}
            </span>
          ) : (
            <span style={{ 
              fontSize: '16px', 
              opacity: 0.5,
              transition: 'opacity 0.2s ease'
            }}>
              ↕
            </span>
          )}
        </div>
      </th>
    );
  };

  // Fetch lookup options for category and county
  useEffect(() => {
    fetch(`${API_BASE_URL}/api/lookups`, { credentials: "include" })
      .then(res => res.json())
      .then(data => {
        setCategoryOptions(data.categories || []);
        setCountyOptions(data.counties || []);
      })
      .catch(() => {
        setCategoryOptions([]);
        setCountyOptions([]);
      });
  }, []);

  if (isLoading) {
    return (
      <MainLayout>
        <div className="dashboard-container">
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            height: '400px'
          }}>
            <div className="spinner" style={{ width: '40px', height: '40px' }}></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="dashboard-container">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          {/* Header */}
          <div className="dashboard-header">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '20px' }}>
              <div>
                <h1 className="dashboard-title" style={{ fontSize: 'clamp(20px, 3.5vw, 26px)', fontWeight: '800', margin: 0 }}>
                  👥 Member Directory
                </h1>
                <p className="dashboard-subtitle" style={{ fontSize: 'clamp(14px, 1.8vw, 17px)', fontWeight: '600', margin: 0 }}>
                  Browse all membership records
                </p>
              </div>
              <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
                {/* Export buttons for private and admin users */}
                {user && (user.role === "private" || user.role === "admin") && (
                  <div style={{ display: 'flex', gap: '12px' }}>
                    <button
                      onClick={() => window.open(`${API_BASE_URL}/api/export/members/csv`, '_blank')}
                      style={{
                        background: 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)',
                        color: 'white',
                        border: '2px solid #16a34a',
                        padding: '14px 28px',
                        borderRadius: '10px',
                        fontSize: '16px',
                        fontWeight: '700',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        transition: 'all 0.2s ease',
                        boxShadow: '0 2px 8px rgba(34, 197, 94, 0.3)'
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.transform = 'translateY(-2px)';
                        e.target.style.boxShadow = '0 4px 12px rgba(34, 197, 94, 0.4)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.transform = 'translateY(0)';
                        e.target.style.boxShadow = '0 2px 8px rgba(34, 197, 94, 0.3)';
                      }}
                    >
                      📊 Export CSV
                    </button>
                    <button
                      onClick={() => window.open(`${API_BASE_URL}/api/export/members/pdf`, '_blank')}
                      style={{
                        background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
                        color: 'white',
                        border: '2px solid #dc2626',
                        padding: '14px 28px',
                        borderRadius: '10px',
                        fontSize: '16px',
                        fontWeight: '700',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        transition: 'all 0.2s ease',
                        boxShadow: '0 2px 8px rgba(239, 68, 68, 0.3)'
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.transform = 'translateY(-2px)';
                        e.target.style.boxShadow = '0 4px 12px rgba(239, 68, 68, 0.4)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.transform = 'translateY(0)';
                        e.target.style.boxShadow = '0 2px 8px rgba(239, 68, 68, 0.3)';
                      }}
                    >
                      📄 Export PDF
                    </button>
                  </div>
                )}
                
                {/* Add Member button for admin only */}
                {user && user.role === "admin" && (
                  <>
                    <Link
                      to="/members/new"
                      style={{
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        padding: '14px 28px',
                        fontSize: '16px',
                        fontWeight: '700',
                        borderRadius: '10px',
                        background: 'linear-gradient(135deg, #14b8a6 0%, #0f766e 100%)',
                        color: 'white',
                        border: '2px solid #0f766e',
                        boxShadow: '0 2px 8px rgba(20, 184, 166, 0.3)',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.transform = 'translateY(-2px)';
                        e.target.style.boxShadow = '0 4px 12px rgba(20, 184, 166, 0.4)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.transform = 'translateY(0)';
                        e.target.style.boxShadow = '0 2px 8px rgba(20, 184, 166, 0.3)';
                      }}
                    >
                      <span>➕</span>
                      Add Member
                    </Link>
                    <button
                      onClick={() => setMergeMode(true)}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        padding: '14px 28px',
                        fontSize: '16px',
                        fontWeight: '700',
                        borderRadius: '10px',
                        background: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
                        color: 'white',
                        border: '2px solid #ea580c',
                        boxShadow: '0 2px 8px rgba(249, 115, 22, 0.3)',
                        transition: 'all 0.2s ease',
                        cursor: 'pointer',
                        fontFamily: 'inherit'
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.transform = 'translateY(-2px)';
                        e.target.style.boxShadow = '0 4px 12px rgba(249, 115, 22, 0.4)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.transform = 'translateY(0)';
                        e.target.style.boxShadow = '0 2px 8px rgba(249, 115, 22, 0.3)';
                      }}
                    >
                      <span>🔗</span>
                      Merge Duplicates
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {error && (
            <div className="alert alert-error" style={{ marginBottom: '32px' }}>
              {error}
            </div>
          )}

          {/* Filter Bar */}
          <div style={{ 
            marginBottom: '32px', 
            padding: '36px', 
            background: '#f0fdfa',
            borderRadius: '16px',
            border: '2px solid #5eead4',
            boxShadow: '0 4px 12px rgba(20, 184, 166, 0.15)'
          }}>
            <h2 style={{ 
              fontSize: 'clamp(16px, 2.2vw, 20px)', 
              fontWeight: '700', 
              color: '#0f766e', 
              margin: 0,
              marginBottom: '28px'
            }}>
              🔍 Search & Filters
            </h2>
            
            {/* Primary Search */}
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '16px', 
              marginBottom: '24px',
              flexWrap: 'wrap'
            }}>
              <input
                type="text"
                placeholder="Search by name, county, email, phone, Irish surname..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="form-input"
                style={{
                  fontSize: '18px',
                  padding: '18px 24px',
                  flex: '1',
                  minWidth: '320px',
                  maxWidth: '600px',
                  border: '2px solid #5eead4',
                  borderRadius: '10px'
                }}
              />
              {(search || roleFilter !== "all" || categoryFilter !== "all" || countyFilter !== "all" || volunteeringFilter !== "all" || sortBy !== "lastName" || sortOrder !== "asc") && (
                <button
                  onClick={() => {
                    setSearch("");
                    setRoleFilter("all");
                    setCategoryFilter("all");
                    setCountyFilter("all");
                    setVolunteeringFilter("all");
                    setSortBy("lastName");
                    setSortOrder("asc");
                    sessionStorage.removeItem('memberSearch');
                    sessionStorage.removeItem('memberRoleFilter');
                    sessionStorage.removeItem('memberCategoryFilter');
                    sessionStorage.removeItem('memberCountyFilter');
                    sessionStorage.removeItem('memberVolunteeringFilter');
                    sessionStorage.removeItem('memberSortBy');
                    sessionStorage.removeItem('memberSortOrder');
                  }}
                  style={{
                    padding: '18px 28px',
                    fontSize: '17px',
                    fontWeight: '700',
                    border: '2px solid #14b8a6',
                    borderRadius: '10px',
                    background: 'white',
                    color: '#0f766e',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    minHeight: '58px'
                  }}
                >
                  <span>✕</span>
                  Clear All
                </button>
              )}
            </div>

            {/* Filters Grid */}
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
              gap: '20px',
              marginBottom: '24px'
            }}>
              <div>
                <label className="form-label" style={{ fontSize: '17px', fontWeight: '700', color: '#0f766e', marginBottom: '14px', display: 'block' }}>Role</label>
                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="form-input"
                  style={{ fontSize: '17px', padding: '18px 24px', border: '2px solid #5eead4', borderRadius: '10px', fontWeight: '600' }}
                >
                  <option value="all">All Roles</option>
                  {roleOptions.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="form-label" style={{ fontSize: '17px', fontWeight: '700', color: '#0f766e', marginBottom: '14px', display: 'block' }}>Category</label>
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="form-input"
                  style={{ fontSize: '17px', padding: '18px 24px', border: '2px solid #5eead4', borderRadius: '10px', fontWeight: '600' }}
                >
                  <option value="all">All Categories</option>
                  {categoryOptions.map((c) => (
                    <option key={c.value} value={c.label}>{c.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="form-label" style={{ fontSize: '17px', fontWeight: '700', color: '#0f766e', marginBottom: '14px', display: 'block' }}>County</label>
                <select
                  value={countyFilter}
                  onChange={(e) => setCountyFilter(e.target.value)}
                  className="form-input"
                  style={{ fontSize: '17px', padding: '18px 24px', border: '2px solid #5eead4', borderRadius: '10px', fontWeight: '600' }}
                >
                  <option value="all">All Counties</option>
                  {countyOptions.map((c) => (
                    <option key={c.id} value={c.label}>{c.label}</option>
                  ))}
                </select>
              </div>
              {user && (user.role === 'admin' || user.role === 'private') && volunteeringOptions.length > 0 && (
                <div>
                  <label className="form-label" style={{ fontSize: '17px', fontWeight: '700', color: '#0f766e', marginBottom: '14px', display: 'block' }}>Volunteering Interest</label>
                  <select
                    value={volunteeringFilter}
                    onChange={(e) => setVolunteeringFilter(e.target.value)}
                    className="form-input"
                    style={{ fontSize: '17px', padding: '18px 24px', border: '2px solid #5eead4', borderRadius: '10px', fontWeight: '600' }}
                  >
                    <option value="all">All Interests</option>
                    {volunteeringOptions.map((v) => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

          </div>

          {/* Results Bar */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '12px',
            margin: '20px 0 16px',
            padding: '0 4px'
          }}>
            <div style={{ fontSize: '17px', fontWeight: '600', color: '#0f766e' }}>
              <strong style={{ fontSize: 'clamp(15px, 2vw, 18px)', fontWeight: '800', color: '#14b8a6' }}>{filtered.length}</strong>
              {' '}{filtered.length === members.length
                ? `total ${filtered.length === 1 ? 'member' : 'members'}`
                : `of ${members.length} ${members.length === 1 ? 'member' : 'members'}`}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ fontSize: '16px', fontWeight: '600', color: '#64748b' }}>Show:</span>
              <select
                value={itemsPerPage}
                onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                style={{ padding: '10px 16px', fontSize: '16px', border: '2px solid #5eead4', borderRadius: '8px', fontWeight: '600', cursor: 'pointer', background: 'white' }}
              >
                <option value={10}>10 per page</option>
                <option value={25}>25 per page</option>
                <option value={50}>50 per page</option>
                <option value={100}>100 per page</option>
                <option value={filtered.length}>All ({filtered.length})</option>
              </select>
            </div>
          </div>

          {/* Bulk Actions Bar */}
          {selectedMembers.size > 0 && (
            <div style={{
              marginBottom: '20px',
              padding: '20px 24px',
              background: 'linear-gradient(135deg, #f0fdfa 0%, #e0f2fe 100%)',
              borderRadius: '12px',
              border: '2px solid #14b8a6',
              display: 'flex',
              alignItems: 'center',
              gap: '16px',
              flexWrap: 'wrap',
              boxShadow: '0 4px 12px rgba(20, 184, 166, 0.15)'
            }}>
              <div style={{ fontSize: '16px', fontWeight: '700', color: '#0f766e' }}>
                {selectedMembers.size} member{selectedMembers.size !== 1 ? 's' : ''} selected
              </div>
              {user && (user.role === 'private' || user.role === 'admin') && (
                <button
                  onClick={handleBulkExport}
                  disabled={bulkExportLoading}
                  style={{
                    padding: '12px 24px',
                    fontSize: '15px',
                    fontWeight: '700',
                    borderRadius: '8px',
                    background: bulkExportLoading ? '#cbd5e1' : 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)',
                    color: 'white',
                    border: '2px solid #16a34a',
                    cursor: bulkExportLoading ? 'not-allowed' : 'pointer',
                    transition: 'all 0.2s ease',
                    opacity: bulkExportLoading ? 0.6 : 1
                  }}
                >
                  {bulkExportLoading ? '⏳ Exporting...' : '📥 Export CSV'}
                </button>
              )}
              {user && user.role === 'admin' && (
                <button
                  onClick={handleBulkDeactivate}
                  disabled={bulkDeactivateLoading}
                  style={{
                    padding: '12px 24px',
                    fontSize: '15px',
                    fontWeight: '700',
                    borderRadius: '8px',
                    background: bulkDeactivateLoading ? '#cbd5e1' : 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
                    color: 'white',
                    border: '2px solid #dc2626',
                    cursor: bulkDeactivateLoading ? 'not-allowed' : 'pointer',
                    transition: 'all 0.2s ease',
                    opacity: bulkDeactivateLoading ? 0.6 : 1
                  }}
                >
                  {bulkDeactivateLoading ? '⏳ Deactivating...' : '🚫 Deactivate'}
                </button>
              )}
              <button
                onClick={() => {
                  setSelectedMembers(new Set());
                  setSelectAll(false);
                }}
                style={{
                  padding: '12px 24px',
                  fontSize: '15px',
                  fontWeight: '700',
                  borderRadius: '8px',
                  background: 'white',
                  color: '#ef4444',
                  border: '2px solid #ef4444',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  marginLeft: 'auto'
                }}
              >
                Clear
              </button>
            </div>
          )}

          {/* Members Table */}
          <div style={{ 
            padding: '36px', 
            background: 'white',
            borderRadius: '16px',
            border: '2px solid #5eead4',
            boxShadow: '0 4px 12px rgba(20, 184, 166, 0.15)',
            overflowX: 'auto'
          }}>
            <div style={{ minWidth: '100%' }}>
                <table style={{ width: '100%', fontSize: '15px', tableLayout: 'auto', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '3px solid #5eead4', background: '#f0fdfa' }}>
                    {/* Select All Checkbox */}
                    <th style={{
                      padding: '20px 16px',
                      textAlign: 'center',
                      width: '50px',
                      minWidth: '50px',
                      fontWeight: '700',
                      color: '#0f766e'
                    }}>
                      <input
                        type="checkbox"
                        checked={selectAll && paginatedMembers.length > 0}
                        onChange={handleSelectAllChange}
                        style={{
                          width: '20px',
                          height: '20px',
                          cursor: 'pointer',
                          accentColor: '#14b8a6'
                        }}
                        title="Select all on this page"
                      />
                    </th>
                    <SortableHeader column="lastName">
                      Surname
                    </SortableHeader>
                    <SortableHeader column="firstName">
                      First Name
                    </SortableHeader>
                    <th style={{
                      padding: '20px',
                      textAlign: 'left',
                      fontWeight: '700',
                      color: '#0f766e',
                      fontSize: '16px',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px',
                      cursor: 'pointer',
                      minWidth: '220px',
                      maxWidth: '280px',
                      whiteSpace: 'normal'
                    }} title="Email address">
                      Email
                    </th>
                    <SortableHeader column="dateJoined">
                      Membership Start
                    </SortableHeader>
                    <SortableHeader column="category">
                      Category
                    </SortableHeader>
                    <SortableHeader column="volunteering">
                      Volunteering
                    </SortableHeader>
                    <th style={{
                      padding: '20px',
                      textAlign: 'left',
                      fontWeight: '700',
                      color: '#0f766e',
                      fontSize: '16px',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px',
                      minWidth: '140px'
                    }}>
                      Status
                    </th>
                    <th style={{
                      padding: '20px',
                      textAlign: 'left',
                      fontWeight: '700',
                      color: '#0f766e',
                      fontSize: '16px',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px'
                    }}>
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan="9" style={{ 
                        textAlign: 'center', 
                        padding: '80px 48px'
                      }}>
                        <div style={{ fontSize: 'clamp(32px, 6vw, 48px)', marginBottom: '20px' }}>
                          {members.length === 0 ? '👥' : '🔍'}
                        </div>
                        <div style={{ 
                          fontSize: 'clamp(16px, 2.2vw, 20px)',
                          fontWeight: '700',
                          color: '#0f766e',
                          marginBottom: '12px'
                        }}>
                          {members.length === 0 ? 'No Members Found' : 'No Matching Members'}
                        </div>
                        <div style={{
                          fontSize: '17px',
                          fontWeight: '500',
                          color: '#64748b'
                        }}>
                          {members.length === 0 ? 'There are no members in the database' : 'No members match your current filters'}
                        </div>
                      </td>
                    </tr>
                  ) : (
                    paginatedMembers.map((m) => (
                      <tr 
                        key={m.id} 
                        style={{ 
                          borderBottom: '2px solid #ccfbf1',
                          background: selectedMembers.has(m.id) ? '#e0f2fe' : 'white',
                          transition: 'background-color 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                          if (!selectedMembers.has(m.id)) {
                            e.target.closest('tr').style.backgroundColor = '#f0fdfa';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (!selectedMembers.has(m.id)) {
                            e.target.closest('tr').style.backgroundColor = 'white';
                          }
                        }}
                      >
                        {/* Checkbox */}
                        <td style={{ padding: '16px', textAlign: 'center', verticalAlign: 'middle' }}>
                          <input
                            type="checkbox"
                            checked={selectedMembers.has(m.id)}
                            onChange={() => handleMemberSelect(m.id)}
                            style={{
                              width: '20px',
                              height: '20px',
                              cursor: 'pointer',
                              accentColor: '#14b8a6'
                            }}
                          />
                        </td>
                        <td style={{ padding: '10px 12px', fontWeight: '700', fontSize: '16px', color: '#0f766e' }}>{m.lastName}</td>
                        <td style={{ padding: '10px 12px', fontSize: '16px', fontWeight: '600', color: '#0f766e' }}>{m.firstName}</td>
                        <td style={{ padding: '10px 12px', color: '#64748b', fontSize: '15px', fontWeight: '500', wordBreak: 'break-word', whiteSpace: 'normal', maxWidth: '280px' }}>{m.email || '—'}</td>
                        <td style={{ padding: '10px 12px', color: '#64748b', fontSize: '15px', fontWeight: '500', whiteSpace: 'nowrap', minWidth: '140px' }}>{m.dateJoined ? new Date(m.dateJoined).toLocaleDateString('en-IE') : '—'}</td>
                        <td style={{ padding: '10px 12px', color: '#64748b', fontSize: '15px', fontWeight: '500', minWidth: '140px' }}>{m.category || '—'}</td>
                        <td style={{ padding: '10px 12px', color: '#64748b', fontSize: '15px', fontWeight: '500', minWidth: '180px', wordBreak: 'break-word', whiteSpace: 'normal' }}>{(m.volunteeringInterests || []).join(', ') || '—'}</td>
                        <td style={{ padding: '10px 12px' }}>
                          <span style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontSize: '13px',
                            fontWeight: '700',
                            background: m.isActive ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)' : '#f1f5f9',
                            color: m.isActive ? 'white' : '#64748b',
                            border: m.isActive ? '1.5px solid #059669' : '1.5px solid #cbd5e1'
                          }}>
                            {m.isActive ? '✓ Active' : '○ Inactive'}
                          </span>
                        </td>
                        <td style={{ padding: '16px 20px', display: 'flex', gap: '10px', flexWrap: 'wrap', alignItems: 'center' }}>
                          {/* View button for all roles */}
                          <Link
                            to={`/members/${m.id}`}
                            style={{
                              fontSize: '15px',
                              fontWeight: '700',
                              lineHeight: '1.2',
                              padding: '10px 18px',
                              borderRadius: '8px',
                              textDecoration: 'none',
                              background: 'linear-gradient(135deg, #14b8a6 0%, #0f766e 100%)',
                              color: 'white',
                              transition: 'all 0.2s ease',
                              border: '2px solid #0f766e',
                              boxShadow: '0 2px 6px rgba(20, 184, 166, 0.3)',
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '6px',
                              whiteSpace: 'nowrap',
                              boxSizing: 'border-box'
                            }}
                            onMouseEnter={e => {
                              e.currentTarget.style.transform = 'translateY(-1px)';
                              e.currentTarget.style.boxShadow = '0 4px 10px rgba(20, 184, 166, 0.45)';
                            }}
                            onMouseLeave={e => {
                              e.currentTarget.style.transform = 'translateY(0)';
                              e.currentTarget.style.boxShadow = '0 2px 6px rgba(20, 184, 166, 0.3)';
                            }}
                          >
                            👁️ View
                          </Link>
                          
                          {/* Edit button for admin only */}
                          {user && user.role === "admin" && (
                            <Link
                              to={`/members/edit/${m.id}`}
                              style={{
                                fontSize: '15px',
                                fontWeight: '700',
                                lineHeight: '1.2',
                                padding: '10px 18px',
                                borderRadius: '8px',
                                textDecoration: 'none',
                                background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                                color: 'white',
                                transition: 'all 0.2s ease',
                                border: '2px solid #d97706',
                                boxShadow: '0 2px 6px rgba(245, 158, 11, 0.3)',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '6px',
                                whiteSpace: 'nowrap',
                                boxSizing: 'border-box'
                              }}
                              onMouseEnter={e => {
                                e.currentTarget.style.transform = 'translateY(-1px)';
                                e.currentTarget.style.boxShadow = '0 4px 10px rgba(245, 158, 11, 0.45)';
                              }}
                              onMouseLeave={e => {
                                e.currentTarget.style.transform = 'translateY(0)';
                                e.currentTarget.style.boxShadow = '0 2px 6px rgba(245, 158, 11, 0.3)';
                              }}
                            >
                              ✏️ Edit
                            </Link>
                          )}

                          {/* Deactivate button for admin only */}
                          {user && user.role === "admin" && m.isActive && (
                            <button
                              onClick={() => {
                                setSelectedMember(m);
                                setShowConfirm(true);
                              }}
                              style={{
                                background: '#fef2f2',
                                border: '2px solid #dc2626',
                                color: '#dc2626',
                                fontSize: '15px',
                                fontWeight: '700',
                                lineHeight: '1.2',
                                cursor: 'pointer',
                                padding: '10px 18px',
                                borderRadius: '8px',
                                transition: 'all 0.2s ease',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '6px',
                                whiteSpace: 'nowrap',
                                boxSizing: 'border-box',
                                fontFamily: 'inherit',
                                WebkitAppearance: 'none',
                                appearance: 'none',
                                boxShadow: '0 2px 6px rgba(220, 38, 38, 0.15)'
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = '#dc2626';
                                e.currentTarget.style.color = 'white';
                                e.currentTarget.style.transform = 'translateY(-1px)';
                                e.currentTarget.style.boxShadow = '0 4px 10px rgba(220, 38, 38, 0.35)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = '#fef2f2';
                                e.currentTarget.style.color = '#dc2626';
                                e.currentTarget.style.transform = 'translateY(0)';
                                e.currentTarget.style.boxShadow = '0 2px 6px rgba(220, 38, 38, 0.15)';
                              }}
                            >
                              🚫 Deactivate
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            {filtered.length > 0 && totalPages > 1 && (
              <div style={{ 
                marginTop: '32px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: '20px',
                padding: '24px',
                background: '#ffffff',
                borderRadius: '12px',
                border: '2px solid #ccfbf1'
              }}>
                {/* Page info */}
                <div style={{ 
                  fontSize: '16px',
                  fontWeight: '600',
                  color: '#0f766e'
                }}>
                  Showing {startIndex + 1}-{Math.min(endIndex, filtered.length)} of {filtered.length} members
                </div>

                {/* Pagination buttons */}
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  {/* Previous button */}
                  <button
                    onClick={() => setCurrentPage(currentPage - 1)}
                    disabled={currentPage === 1}
                    style={{
                      padding: '14px 24px',
                      fontSize: '16px',
                      fontWeight: '700',
                      border: '2px solid #5eead4',
                      borderRadius: '8px',
                      background: currentPage === 1 ? '#f1f5f9' : '#ffffff',
                      color: currentPage === 1 ? '#94a3b8' : '#0f766e',
                      cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                      transition: 'all 0.2s ease',
                      opacity: currentPage === 1 ? 0.5 : 1
                    }}
                    onMouseEnter={(e) => {
                      if (currentPage !== 1) {
                        e.target.style.background = '#ccfbf1';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (currentPage !== 1) {
                        e.target.style.background = '#ffffff';
                      }
                    }}
                  >
                    ← Previous
                  </button>

                  {/* Page numbers */}
                  <div style={{ display: 'flex', gap: '4px' }}>
                    {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                      let pageNum;
                      if (totalPages <= 7) {
                        pageNum = i + 1;
                      } else if (currentPage <= 4) {
                        pageNum = i + 1;
                      } else if (currentPage >= totalPages - 3) {
                        pageNum = totalPages - 6 + i;
                      } else {
                        pageNum = currentPage - 3 + i;
                      }

                      return (
                        <button
                          key={pageNum}
                          onClick={() => setCurrentPage(pageNum)}
                          style={{
                            padding: '14px 18px',
                            fontSize: '16px',
                            fontWeight: '700',
                            border: currentPage === pageNum ? '2px solid #14b8a6' : '2px solid #e5e7eb',
                            borderRadius: '8px',
                            background: currentPage === pageNum ? '#14b8a6' : '#ffffff',
                            color: currentPage === pageNum ? '#ffffff' : '#64748b',
                            cursor: 'pointer',
                            transition: 'all 0.2s ease',
                            minWidth: '48px'
                          }}
                          onMouseEnter={(e) => {
                            if (currentPage !== pageNum) {
                              e.target.style.background = '#f0fdfa';
                              e.target.style.borderColor = '#5eead4';
                              e.target.style.color = '#0f766e';
                            }
                          }}
                          onMouseLeave={(e) => {
                            if (currentPage !== pageNum) {
                              e.target.style.background = '#ffffff';
                              e.target.style.borderColor = '#e5e7eb';
                              e.target.style.color = '#64748b';
                            }
                          }}
                        >
                          {pageNum}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next button */}
                  <button
                    onClick={() => setCurrentPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    style={{
                      padding: '14px 24px',
                      fontSize: '16px',
                      fontWeight: '700',
                      border: '2px solid #5eead4',
                      borderRadius: '8px',
                      background: currentPage === totalPages ? '#f1f5f9' : '#ffffff',
                      color: currentPage === totalPages ? '#94a3b8' : '#0f766e',
                      cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                      transition: 'all 0.2s ease',
                      opacity: currentPage === totalPages ? 0.5 : 1
                    }}
                    onMouseEnter={(e) => {
                      if (currentPage !== totalPages) {
                        e.target.style.background = '#ccfbf1';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (currentPage !== totalPages) {
                        e.target.style.background = '#ffffff';
                      }
                    }}
                  >
                    Next →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {showConfirm && selectedMember && (
        <DeactivateConfirm
          memberName={`${selectedMember.firstName} ${selectedMember.lastName}`}
          onCancel={() => {
            setShowConfirm(false);
            setSelectedMember(null);
          }}
          onConfirm={handleConfirmDeactivate}
        />
      )}

      {/* Merge Modal */}
      {mergeMode && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px'
        }}>
          <div style={{
            background: 'white',
            borderRadius: '16px',
            border: '2px solid #14b8a6',
            maxWidth: '700px',
            width: '100%',
            padding: '36px',
            boxShadow: '0 20px 25px rgba(0, 0, 0, 0.15)',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            <h2 style={{ fontSize: '24px', fontWeight: '800', color: '#0f766e', margin: '0 0 24px' }}>
              🔗 Merge Duplicate Members
            </h2>
            <p style={{ fontSize: '16px', color: '#64748b', marginBottom: '32px', fontWeight: '500' }}>
              Select two members to merge. The secondary member will be deleted after merging all their data.
            </p>

            {/* Primary Member Selection */}
            <div style={{ marginBottom: '32px' }}>
              <label style={{ fontSize: '16px', fontWeight: '700', color: '#0f766e', display: 'block', marginBottom: '12px' }}>
                Primary Member (Keep this one):
              </label>
              <input
                type="text"
                placeholder="Search by name, email, phone..."
                value={mergeSearchPrimary}
                onChange={(e) => setMergeSearchPrimary(e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  fontSize: '16px',
                  border: '2px solid #5eead4',
                  borderRadius: '10px',
                  fontWeight: '600',
                  marginBottom: '12px',
                  boxSizing: 'border-box'
                }}
              />
              <div style={{
                border: '2px solid #e5e7eb',
                borderRadius: '10px',
                maxHeight: '200px',
                overflowY: 'auto',
                background: '#f9fafb'
              }}>
                {members
                  .filter(m => 
                    `${m.firstName} ${m.lastName} ${m.email || ''} ${m.phoneNumber || ''}`
                      .toLowerCase()
                      .includes(mergeSearchPrimary.toLowerCase())
                  )
                  .slice(0, 20)
                  .map(m => (
                    <div
                      key={m.id}
                      onClick={() => setMergePrimary(m)}
                      style={{
                        padding: '12px 16px',
                        borderBottom: '1px solid #e5e7eb',
                        cursor: 'pointer',
                        background: mergePrimary?.id === m.id ? '#14b8a6' : 'white',
                        color: mergePrimary?.id === m.id ? 'white' : '#0f766e',
                        fontWeight: mergePrimary?.id === m.id ? '700' : '600',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        if (mergePrimary?.id !== m.id) {
                          e.currentTarget.style.background = '#f0fdfa';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (mergePrimary?.id !== m.id) {
                          e.currentTarget.style.background = 'white';
                        }
                      }}
                    >
                      {m.firstName} {m.lastName} {m.email && `(${m.email})`}
                    </div>
                  ))}
              </div>
            </div>

            {/* Secondary Member Selection */}
            <div style={{ marginBottom: '32px' }}>
              <label style={{ fontSize: '16px', fontWeight: '700', color: '#0f766e', display: 'block', marginBottom: '12px' }}>
                Secondary Member (Delete this one):
              </label>
              <input
                type="text"
                placeholder="Search by name, email, phone..."
                value={mergeSearchSecondary}
                onChange={(e) => setMergeSearchSecondary(e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  fontSize: '16px',
                  border: '2px solid #5eead4',
                  borderRadius: '10px',
                  fontWeight: '600',
                  marginBottom: '12px',
                  boxSizing: 'border-box'
                }}
              />
              <div style={{
                border: '2px solid #e5e7eb',
                borderRadius: '10px',
                maxHeight: '200px',
                overflowY: 'auto',
                background: '#f9fafb'
              }}>
                {members
                  .filter(m => 
                    m.id !== mergePrimary?.id &&
                    `${m.firstName} ${m.lastName} ${m.email || ''} ${m.phoneNumber || ''}`
                      .toLowerCase()
                      .includes(mergeSearchSecondary.toLowerCase())
                  )
                  .slice(0, 20)
                  .map(m => (
                    <div
                      key={m.id}
                      onClick={() => setMergeSecondary(m)}
                      style={{
                        padding: '12px 16px',
                        borderBottom: '1px solid #e5e7eb',
                        cursor: 'pointer',
                        background: mergeSecondary?.id === m.id ? '#f97316' : 'white',
                        color: mergeSecondary?.id === m.id ? 'white' : '#0f766e',
                        fontWeight: mergeSecondary?.id === m.id ? '700' : '600',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        if (mergeSecondary?.id !== m.id) {
                          e.currentTarget.style.background = '#fef3f2';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (mergeSecondary?.id !== m.id) {
                          e.currentTarget.style.background = 'white';
                        }
                      }}
                    >
                      {m.firstName} {m.lastName} {m.email && `(${m.email})`}
                    </div>
                  ))}
              </div>
            </div>

            {mergePrimary && mergeSecondary && (
              <div style={{
                background: '#f0fdfa',
                border: '2px solid #5eead4',
                borderRadius: '10px',
                padding: '16px',
                marginBottom: '24px',
                fontSize: '14px',
                color: '#0f766e'
              }}>
                <strong>✓ Merge Plan:</strong><br/>
                Keep: <strong>{mergePrimary.firstName} {mergePrimary.lastName}</strong><br/>
                Delete: <strong>{mergeSecondary.firstName} {mergeSecondary.lastName}</strong>
              </div>
            )}

            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
              <button
                onClick={() => {
                  setMergeMode(false);
                  setMergePrimary(null);
                  setMergeSecondary(null);
                  setMergeSearchPrimary("");
                  setMergeSearchSecondary("");
                }}
                style={{
                  padding: '14px 28px',
                  fontSize: '16px',
                  fontWeight: '700',
                  border: '2px solid #e5e7eb',
                  borderRadius: '10px',
                  background: 'white',
                  color: '#64748b',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.target.style.background = '#f1f5f9';
                }}
                onMouseLeave={(e) => {
                  e.target.style.background = 'white';
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleMergeMembers}
                disabled={!mergePrimary || !mergeSecondary}
                style={{
                  padding: '14px 28px',
                  fontSize: '16px',
                  fontWeight: '700',
                  border: '2px solid #f97316',
                  borderRadius: '10px',
                  background: (mergePrimary && mergeSecondary) ? '#f97316' : '#cbd5e1',
                  color: 'white',
                  cursor: (mergePrimary && mergeSecondary) ? 'pointer' : 'not-allowed',
                  transition: 'all 0.2s ease',
                  opacity: (mergePrimary && mergeSecondary) ? 1 : 0.5
                }}
                onMouseEnter={(e) => {
                  if (mergePrimary && mergeSecondary) {
                    e.target.style.background = '#ea580c';
                  }
                }}
                onMouseLeave={(e) => {
                  if (mergePrimary && mergeSecondary) {
                    e.target.style.background = '#f97316';
                  }
                }}
              >
                Merge Members
              </button>
            </div>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
