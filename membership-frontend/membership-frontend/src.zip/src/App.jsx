import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import AdminDashboard from "./pages/dashboard/admin";
import AdminStats from "./pages/admin/stats";
import Members from "./pages/members/member";
import Signup from "./pages/auth/signup";
import Login from "./pages/auth/login";
import ForgotEmail from "./pages/auth/forgot-email";
import ForgotNoEmail from "./pages/auth/forgot-no-email";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" />} />
        <Route path="/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/stats" element={<AdminStats />} />
        <Route path="/members" element={<Members />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/forgot-password/email" element={<ForgotEmail />} />
        <Route path="/forgot-password/manual" element={<ForgotNoEmail />} />
        <Route path="*" element={<div className="p-6">404: Page not found</div>} />
      </Routes>
    </Router>
  );
}

export default App;
