import { useAuth } from "../hooks/useauth";

export default function Navbar() {
  const { user } = useAuth();

  // Add a safety check in case user is null
  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <header className="bg-white shadow px-6 py-3 flex items-center justify-between">
      <h1 className="text-xl font-semibold">BIS Membership System</h1>

      <div className="flex items-center gap-4">
        <span className="text-sm bg-gray-200 px-3 py-1 rounded-full">
          {user.role?.charAt(0).toUpperCase() + user.role?.slice(1)} User
        </span>

        <div className="relative group">
          <button className="text-sm font-medium hover:underline">
            {user.name || `${user.firstName} ${user.lastName}`}
          </button>
          <div className="absolute right-0 mt-2 hidden group-hover:block bg-white border rounded shadow w-40">
            <a href="/my-profile" className="block px-4 py-2 hover:bg-gray-100">My Account</a>
            <a href="/settings" className="block px-4 py-2 hover:bg-gray-100">Settings</a>
            <a href="/logout" className="block px-4 py-2 hover:bg-gray-100 text-red-600">Logout</a>
          </div>
        </div>
      </div>
    </header>
  );
}