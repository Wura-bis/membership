import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../hooks/useauth";

const linksByRole = {
  admin: [
    { to: "/", label: "Dashboard" },
    { to: "/admin/stats", label: "Stats" },
    { to: "/users", label: "User Management" },
    { to: "/members", label: "Members" },
    { to: "/import", label: "Import/Export" },
    { to: "/settings", label: "System Settings" },
  ],
  private: [
    { to: "/members", label: "Directory" },
    { to: "/my-profile", label: "My Profile" },
  ],
  public: [
    { to: "/members", label: "Directory" },
    { to: "/my-profile", label: "My Profile" },
  ],
};

export default function Sidebar() {
  const { user } = useAuth();
  const location = useLocation();

  // Default to public if no user or role
  const userRole = user?.role || "public";
  const links = linksByRole[userRole] || [];

  return (
    <aside className="w-64 bg-white border-r shadow-sm">
      <div className="p-4 font-bold text-blue-700 text-lg">BIS</div>
      <nav className="flex flex-col gap-1 p-2">
        {links.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className={`px-4 py-2 rounded ${
              location.pathname === link.to
                ? "bg-blue-100 text-blue-800 font-semibold"
                : "hover:bg-gray-100"
            }`}
          >
            {link.label}
          </Link>
        ))}
      </nav>
    </aside>
  );
}