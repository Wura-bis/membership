import { useEffect, useState } from "react";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";

export default function AdminStats() {
  const [stats, setStats] = useState(null);
  const [category, setCategory] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    fetchStats(); // Initial load
  }, []);

  const fetchStats = async () => {
    try {
      const query = new URLSearchParams({
        startDate,
        endDate,
        category,
      }).toString();

      const res = await fetch(`http://localhost:5000/api/admin/stats?${query}`, {
        credentials: "include",
      });
      const data = await res.json();

      if (!data.total) {
        setStats({
          total: 0,
          growth: 0,
          breakdown: { active: 0, inactive: 0, deceased: 0 },
          yearly: {},
        });
      } else {
        setStats(data);
      }

      setError("");
    } catch {
      setError("Failed to fetch stats");
    }
  };

  const handleExport = () => {
    if (!stats) return alert("No stats to export");

    const rows = [
      ["Metric", "Value"],
      ["Total Members", stats.total],
      ["Growth", `${stats.growth}%`],
      ["Active", stats.breakdown.active],
      ["Inactive", stats.breakdown.inactive],
      ["Deceased", stats.breakdown.deceased],
    ];

    for (const year in stats.yearly) {
      rows.push([`New Members (${year})`, stats.yearly[year]]);
    }

    const csvContent = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "membership_stats.csv";
    a.click();

    URL.revokeObjectURL(url);
  };

  const COLORS = ["#38bdf8", "#facc15", "#f87171"];

  const pieData = stats
    ? [
        { name: "Active", value: stats.breakdown.active },
        { name: "Inactive", value: stats.breakdown.inactive },
        { name: "Deceased", value: stats.breakdown.deceased },
      ]
    : [];

  const lineData = stats
    ? Object.entries(stats.yearly).map(([year, value]) => ({
        year,
        value,
      }))
    : [];

  return (
    <div className="p-6 bg-blue-50 min-h-screen">
      <h1 className="text-2xl font-semibold mb-4">Membership Stats</h1>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        <div>
          <label className="block text-sm mb-1">Start Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="border px-3 py-2 rounded"
          />
        </div>
        <div>
          <label className="block text-sm mb-1">End Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="border px-3 py-2 rounded"
          />
        </div>
        <div>
          <label className="block text-sm mb-1">Category</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="border px-3 py-2 rounded"
          >
            <option value="">All</option>
            <option value="Honorary">Honorary</option>
            <option value="Associate">Associate</option>
            <option value="Full">Full</option>
          </select>
        </div>
        <button
          onClick={fetchStats}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Apply Filters
        </button>
        <button
          onClick={handleExport}
          className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700"
        >
          Export CSV
        </button>
      </div>

      {error && <p className="text-red-600">{error}</p>}

      {!stats ? (
        <p className="text-gray-600">Loading stats...</p>
      ) : (
        <div className="grid gap-6">
          {/* Stat Card */}
          <div className="bg-white p-4 rounded shadow flex items-center justify-between">
            <div>
              <h2 className="text-sm text-gray-500 mb-1">Total Members</h2>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
            <div className="text-right">
              <h2 className="text-sm text-gray-500 mb-1">Increase</h2>
              <p className="text-xl text-green-600 font-bold">{stats.growth}%</p>
            </div>
          </div>

          {/* Charts */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded shadow">
              <h3 className="text-sm mb-2 font-semibold">Status Breakdown</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label
                  >
                    {pieData.map((_, index) => (
                      <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white p-4 rounded shadow">
              <h3 className="text-sm mb-2 font-semibold">New Members Per Year</h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={lineData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" stroke="#3b82f6" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
