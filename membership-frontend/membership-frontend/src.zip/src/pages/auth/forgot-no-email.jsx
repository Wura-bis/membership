import { useState } from "react";

export default function ForgotNoEmail() {
  const [userID, setUserID] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleReset = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");

    if (password !== confirm) {
      return setError("Passwords do not match");
    }

    try {
      const res = await fetch("http://localhost:5000/api/reset-no-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userID, newPassword: password }),
      });

      if (res.ok) {
        setMessage("Password reset successful. You can now log in.");
        setUserID("");
        setPassword("");
        setConfirm("");
      } else {
        const err = await res.json();
        setError(err.message || "Reset failed");
      }
    } catch {
      setError("Server error");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="bg-white p-8 rounded shadow w-full max-w-md">
        <h2 className="text-2xl font-semibold mb-6 text-center">Reset Password</h2>

        {error && <p className="text-red-600 mb-4 text-sm text-center">{error}</p>}
        {message && <p className="text-green-600 mb-4 text-sm text-center">{message}</p>}

        <form onSubmit={handleReset} className="space-y-4">
          <div>
            <label className="block text-sm mb-1">User ID</label>
            <input
              type="text"
              required
              value={userID}
              onChange={(e) => setUserID(e.target.value)}
              className="w-full px-4 py-2 border rounded"
            />
          </div>

          <div>
            <label className="block text-sm mb-1">New Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border rounded"
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Confirm New Password</label>
            <input
              type="password"
              required
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="w-full px-4 py-2 border rounded"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
          >
            Reset Password
          </button>
        </form>
      </div>
    </div>
  );
}
