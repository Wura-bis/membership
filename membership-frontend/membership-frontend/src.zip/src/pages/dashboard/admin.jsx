import { useEffect, useState } from "react";
import MainLayout from "../../components/mainlayout";

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [activities, setActivities] = useState([]);
  const [error, setError] = useState("");
  const [user, setUser] = useState({ firstName: "Admin", lastName: "" });

  useEffect(() => {
    // Fetch dashboard stats and recent activities
    fetch("http://localhost:5000/api/admin/dashboard", {
      credentials: "include",
    })
      .then((res) => res.json())
      .then((data) => {
        setStats(data.stats);
        setActivities(data.recentActivities);
        setUser(data.adminUser || { firstName: "Admin", lastName: "" });
      })
      .catch(() => setError("Failed to load dashboard"));
  }, []);

  return (
    <MainLayout>
      <div className="p-6 bg-blue-50 min-h-screen">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold">
            Welcome back, {user.firstName} {user.lastName}!
          </h1>
          <span className="bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
            ADMINISTRATOR
          </span>
        </div>

        {error && <p className="text-red-600">{error}</p>}

        <div className="grid gap-4 md:grid-cols-3 mb-6">
          {/* Member Summary */}
          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-sm font-semibold mb-2">Member Summary</h2>
            <p className="text-sm">
              <strong>{stats?.activeMembers ?? "—"}</strong> Active Memberships
            </p>
            <p className="text-sm">
              <strong>{stats?.inactiveMembers ?? "—"}</strong> Non-Active Memberships
            </p>
            <button className="mt-3 text-sm bg-gray-200 px-3 py-1 rounded hover:bg-gray-300">
              View All
            </button>
          </div>

          {/* Recent Activities */}
          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-sm font-semibold mb-2">Recent Activities</h2>
            <ul className="text-sm text-gray-700 space-y-1">
              {activities.length === 0 ? (
                <li>No recent activity</li>
              ) : (
                activities.map((item, i) => (
                  <li key={i}>
                    {item.type}: {item.name} on {item.date}
                  </li>
                ))
              )}
            </ul>
          </div>

          {/* Quick Actions */}
          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-sm font-semibold mb-2">Quick Actions</h2>
            <div className="flex flex-col space-y-2">
              <a href="/members/new" className="btn-action">
                ➕ Add New Member
              </a>
              <a href="/admin/export" className="btn-action">
                📄 Generate Lists
              </a>
              <a href="/members/edit" className="btn-action">
                ✏️ Edit Membership
              </a>
            </div>
          </div>
        </div>

        {/* Announcements / Notifications */}
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-sm font-semibold mb-2">Announcements / Notifications</h2>
          <ul className="text-sm text-gray-700 list-disc pl-5">
            <li>Can now update the "active" status in the member view directly.</li>
            <li>Support requests and login issues now visible in admin settings.</li>
            <li>Don’t forget to review pending user approvals this week.</li>
          </ul>
        </div>
      </div>
    </MainLayout>
  );
}
