import { useEffect, useState } from "react";
import MainLayout from "../../components/mainlayout";
import {
  PieChart, Pie, Cell,
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer
} from "recharts";

const COLORS = ["#8884d8", "#82ca9d", "#ffc658"];

export default function PublicDashboard() {
  const [stats, setStats] = useState(null);

    useEffect(() => {
      fetch("http://localhost:5000/api/public/dashboard")
        .then((res) => {
          if (!res.ok) throw new Error("Failed to fetch");
          return res.json();
        })
        .then((data) => setStats(data))
        .catch((err) => {
          console.error("Dashboard load error:", err);
        });
    }, []);


  return (
    <MainLayout>
      <div className="p-6 bg-blue-50 min-h-screen">
        <div className="mb-4">
          <h1 className="text-2xl font-semibold">Public Dashboard</h1>
          <p className="text-sm text-gray-700 mt-1">
            Welcome! Explore membership stats and find out more about our membership
          </p>
        </div>

        {!stats ? (
          <p>Loading...</p>
        ) : (
          <>
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              {/* Total Registered Members */}
              <div className="bg-white p-4 rounded shadow text-center">
                <p className="text-sm font-semibold mb-2">Total Registered Members</p>
                <p className="text-4xl font-bold">{stats.totalMembers.toLocaleString()}</p>
              </div>

              {/* Membership Categories */}
              <div className="bg-white p-4 rounded shadow text-center">
                <p className="text-sm font-semibold mb-2">Membership Categories</p>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie
                      data={stats.categories}
                      dataKey="value"
                      nameKey="name"
                      outerRadius={70}
                      label
                    >
                      {stats.categories.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Regional Representations */}
              <div className="bg-white p-4 rounded shadow text-center">
                <p className="text-sm font-semibold mb-2">Regional Representations (Top 10)</p>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={stats.regions}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Historical Highlights */}
            <div className="bg-white p-4 rounded shadow">
              <p className="text-sm font-semibold mb-2">Historical Membership Highlights</p>
              <ul className="text-sm list-disc pl-5 text-gray-700 space-y-1">
                <li>First Member Registered: {stats.historical.firstRegistered}</li>
                <li>Most Members Registered in a Year: {stats.historical.mostInAYear}</li>
                <li>Lifetime Memberships Awarded: {stats.historical.lifetime}</li>
              </ul>
            </div>
          </>
        )}
      </div>
    </MainLayout>
  );
}
