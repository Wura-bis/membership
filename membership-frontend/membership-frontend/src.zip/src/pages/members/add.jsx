import { useState, useEffect } from "react";
import MainLayout from "../../components/mainlayout";

export default function AddMember() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    county: "",
    category: "",
    dateJoined: "",
    proposer: "",
    seconder: "",
    proposalDate: "",
    roles: [],
    fiscalYears: [],
    societies: [],
    addresses: [{ address: "", postalCode: "", fiscalYear: "" }],
  });

  const [lookups, setLookups] = useState({ counties: [], categories: [], roles: [], fiscalYears: [], societies: [] });

  useEffect(() => {
    fetch("http://localhost:5000/api/lookups")
      .then(res => res.json())
      .then(setLookups);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddressChange = (index, field, value) => {
    const updated = [...formData.addresses];
    updated[index][field] = value;
    setFormData((prev) => ({ ...prev, addresses: updated }));
  };

  const addAddress = () => {
    setFormData((prev) => ({ ...prev, addresses: [...prev.addresses, { address: "", postalCode: "", fiscalYear: "" }] }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:5000/api/members", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    })
      .then((res) => res.json())
      .then((data) => alert("Member added!"))
      .catch(() => alert("Failed to add member."));
  };

  return (
    <MainLayout>
      <div className="p-6 max-w-4xl mx-auto">
        <h1 className="text-xl font-bold mb-4">Add New Member</h1>

        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="grid grid-cols-2 gap-4">
            <input name="firstName" value={formData.firstName} onChange={handleChange} placeholder="First Name" className="input" />
            <input name="lastName" value={formData.lastName} onChange={handleChange} placeholder="Last Name" className="input" />
            <input name="email" value={formData.email} onChange={handleChange} placeholder="Email" className="input" />
            <input name="phone" value={formData.phone} onChange={handleChange} placeholder="Phone" className="input" />
            <select name="county" value={formData.county} onChange={handleChange} className="input">
              <option value="">Select County</option>
              {lookups.counties.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <select name="category" value={formData.category} onChange={handleChange} className="input">
              <option value="">Select Category</option>
              {lookups.categories.map((cat) => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <input name="dateJoined" value={formData.dateJoined} onChange={handleChange} type="date" className="input" placeholder="Date Joined" />
            <input name="proposalDate" value={formData.proposalDate} onChange={handleChange} type="date" className="input" placeholder="Proposal Date" />
            <input name="proposer" value={formData.proposer} onChange={handleChange} placeholder="Proposer" className="input" />
            <input name="seconder" value={formData.seconder} onChange={handleChange} placeholder="Seconder" className="input" />
          </div>

          {/* Addresses Section */}
          <div>
            <h2 className="font-semibold mb-2">Addresses</h2>
            {formData.addresses.map((addr, idx) => (
              <div key={idx} className="grid grid-cols-3 gap-2 mb-2">
                <input value={addr.address} onChange={(e) => handleAddressChange(idx, "address", e.target.value)} placeholder="Address" className="input" />
                <input value={addr.postalCode} onChange={(e) => handleAddressChange(idx, "postalCode", e.target.value)} placeholder="Postal Code" className="input" />
                <select value={addr.fiscalYear} onChange={(e) => handleAddressChange(idx, "fiscalYear", e.target.value)} className="input">
                  <option value="">Select Year</option>
                  {lookups.fiscalYears.map((fy) => (
                    <option key={fy.id} value={fy.id}>{fy.name}</option>
                  ))}
                </select>
              </div>
            ))}
            <button type="button" onClick={addAddress} className="text-blue-600">+ Add another address</button>
          </div>

          {/* Roles & Societies */}
          <div className="grid grid-cols-2 gap-4">
            <select multiple value={formData.roles} onChange={(e) => setFormData((f) => ({ ...f, roles: Array.from(e.target.selectedOptions, o => o.value) }))} className="input h-32">
              {lookups.roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
            <select multiple value={formData.societies} onChange={(e) => setFormData((f) => ({ ...f, societies: Array.from(e.target.selectedOptions, o => o.value) }))} className="input h-32">
              {lookups.societies.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>

          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Submit</button>
        </form>
      </div>
    </MainLayout>
  );
}
