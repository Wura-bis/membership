import { useEffect, useState } from "react";

export default function Members() {
  const [members, setMembers] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [countyFilter, setCountyFilter] = useState("all");
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/api/members", {
      credentials: "include",
    })
      .then((res) => res.json())
      .then((data) => setMembers(data))
      .catch(() => setError("Failed to load members"));
  }, []);

  const filtered = members.filter((m) => {
    const matchesSearch =
      [m.firstName, m.lastName, m.county]
        .join(" ")
        .toLowerCase()
        .includes(search.toLowerCase());

    const matchesStatus =
      statusFilter === "all"
        ? true
        : statusFilter === "active"
        ? m.isActive
        : !m.isActive;

    const matchesCategory =
      categoryFilter === "all" || m.category === categoryFilter;

    const matchesCounty =
      countyFilter === "all" || m.county === countyFilter;

    return matchesSearch && matchesStatus && matchesCategory && matchesCounty;
  });

  const categoryOptions = [
    "Honorary",
    "Ordinary",
    "Associate",
    "Fellow",
    "Student",
  ];

  const countyOptions = [
    "Dublin",
    "Cork",
    "Galway",
    "Limerick",
    "Kerry",
    "Mayo",
    "Wexford",
    "Donegal",
    // ... Fill with all counties from your IrishCounties table
  ];

  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-4">Members Directory</h1>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
        <input
          type="text"
          placeholder="Search by name or county..."
          className="px-4 py-2 border rounded w-full"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          className="px-4 py-2 border rounded w-full"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="all">All Statuses</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>

        <select
          className="px-4 py-2 border rounded w-full"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          <option value="all">All Categories</option>
          {categoryOptions.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>

        <select
          className="px-4 py-2 border rounded w-full"
          value={countyFilter}
          onChange={(e) => setCountyFilter(e.target.value)}
        >
          <option value="all">All Counties</option>
          {countyOptions.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {error && <p className="text-red-600">{error}</p>}

      {/* Table */}
      <div className="overflow-x-auto bg-white rounded shadow">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-100 text-left">
            <tr>
              <th className="p-3">Surname</th>
              <th className="p-3">First Name</th>
              <th className="p-3">County</th>
              <th className="p-3">Category</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan="5" className="p-4 text-center text-gray-500">
                  No members found
                </td>
              </tr>
            ) : (
              filtered.map((member) => (
                <tr key={member.id} className="border-b hover:bg-gray-50">
                  <td className="p-3">{member.lastName}</td>
                  <td className="p-3">{member.firstName}</td>
                  <td className="p-3">{member.county}</td>
                  <td className="p-3">{member.category}</td>
                  <td className="p-3">
                    <span
                      className={`inline-block px-2 py-1 text-xs rounded-full ${
                        member.isActive
                          ? "bg-green-100 text-green-700"
                          : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {member.isActive ? "Active" : "Inactive"}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
