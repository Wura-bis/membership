<?php
// ── List members ──────────────────────────────────────────────────────────────
function get_members_list(): void {
    $user = require_auth();
    $role = $user['role'];

    $db = get_db();

    $sql = '
        SELECT m.MemberID, m.FirstName, m.LastName,
               m.`Place of Birth`, m.`Date of Birth`,
               m.IsActive, mc.CategoryName,
               m.DateJoined, m.DateEnded,
               m.Email, m.PhoneNumber,
               m.ApprovedBy, m.SignedBy, m.Proposer, m.Seconder,
               o.OccupationName, m.OtherSocieties, m.Notes
        FROM Members AS m
        LEFT JOIN MemberCategory AS mc ON m.MemberCategoryID = mc.CategoryID
        LEFT JOIN Occupation AS o ON m.OccupationID = o.OccupationID
    ';

    // Role-based visibility
    if ($role === 'public') {
        $sql .= " WHERE mc.CategoryName = 'Historical'";
    }

    // Get sort parameters from query string
    $sort_by = $_GET['sortBy'] ?? 'lastName';
    $sort_order = strtoupper($_GET['sortOrder'] ?? 'ASC');

    // Whitelist of allowed sortable fields
    $allowed_sorts = [
        'firstName', 'lastName', 'dateOfBirth', 'isActive', 
        'category', 'county', 'dateJoined', 'dateEnded',
        'email', 'phoneNumber', 'occupation'
    ];

    // Validate sort field and order
    if (!in_array($sort_by, $allowed_sorts)) {
        $sort_by = 'lastName';
    }
    if (!in_array($sort_order, ['ASC', 'DESC'])) {
        $sort_order = 'ASC';
    }

    // Map field names to table columns
    $sort_map = [
        'firstName' => 'm.FirstName',
        'lastName' => 'm.LastName',
        'dateOfBirth' => 'm.`Date of Birth`',
        'isActive' => 'm.IsActive',
        'category' => 'mc.CategoryName',
        'dateJoined' => 'm.DateJoined',
        'dateEnded' => 'm.DateEnded',
        'email' => 'm.Email',
        'phoneNumber' => 'm.PhoneNumber',
        'occupation' => 'o.OccupationName',
        'county' => 'ict.CountyName'
    ];

    $sort_column = $sort_map[$sort_by] ?? 'm.LastName';
    $sql .= " ORDER BY $sort_column $sort_order";

    $stmt = $db->query($sql);
    $rows = $stmt->fetchAll();

    $members = [];
    $ids     = [];

    foreach ($rows as $r) {
        $mid     = $r[0];
        $ids[]   = $mid;
        $is_active = (bool)($r[5] == 1 || $r[5] === '1' || $r[5] === 'True');

        $joined = format_date($r[7]);
        $ended  = format_date($r[8]);
        $years  = null;
        if ($joined) {
            $end_dt  = $ended ? new DateTime($ended) : new DateTime();
            $start_dt = new DateTime($joined);
            $years   = (int)$start_dt->diff($end_dt)->y;
        }

        $members[$mid] = [
            'id'          => $mid,
            'firstName'   => $r[1],
            'lastName'    => $r[2],
            'placeOfBirth'=> $r[3] ?? '',
            'dateOfBirth' => format_date($r[4]),
            'isActive'    => $is_active,
            'category'    => $r[6] ?? '',
            'county'      => '',
            'dateJoined'  => $joined,
            'dateEnded'   => $ended,
            'membershipYears' => $years,
            'address'     => '',
            'addressSearch' => '',
            'role'        => '',
            'email'       => $r[9] ?? '',
            'phoneNumber' => $r[10] ?? '',
            'approvedBy'  => $r[11] ?? '',
            'signedBy'    => $r[12] ?? '',
            'proposer'    => $r[13] ?? '',
            'seconder'    => $r[14] ?? '',
            'occupation'  => $r[15] ?? '',
            'otherSocieties' => $r[16] ?? '',
            'notes'       => $r[17] ?? '',
            'volunteeringInterests' => [],
            'irishSurnames'  => [],
            'allPhones'      => [],
            'allCounties'    => [],
        ];
    }

    if (empty($ids)) { json_out([]); }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    // Batch: all counties
    $stmt = $db->prepare("
        SELECT ic.MemberID, ict.CountyName
        FROM IrishConnectionByCounty AS ic
        LEFT JOIN IrishCounties AS ict ON ic.CountyID = ict.CountyID
        WHERE ic.MemberID IN ($placeholders) AND ict.CountyName IS NOT NULL
    ");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) {
        $mid = $r[0];
        if (isset($members[$mid])) {
            $members[$mid]['allCounties'][] = $r[1];
            if (!$members[$mid]['county']) $members[$mid]['county'] = $r[1];
        }
    }

    // Batch: Irish surnames
    $stmt = $db->prepare("
        SELECT ics.MemberID, isur.Surname
        FROM IrishConnectionBySurname AS ics
        LEFT JOIN IrishSurnames AS isur ON ics.SurnameID = isur.SurnameID
        WHERE ics.MemberID IN ($placeholders) AND isur.Surname IS NOT NULL
    ");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) {
        if (isset($members[$r[0]])) $members[$r[0]]['irishSurnames'][] = $r[1];
    }

    // Batch: phone numbers
    $stmt = $db->prepare("
        SELECT MemberID, PhoneNumber
        FROM MemberPhoneNumbers
        WHERE MemberID IN ($placeholders) AND PhoneNumber IS NOT NULL
    ");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) {
        if (isset($members[$r[0]])) $members[$r[0]]['allPhones'][] = $r[1];
    }

    // Batch: volunteering interests
    $stmt = $db->prepare("
        SELECT udfv.MemberID, udfv.ValueText
        FROM UserDefinedFieldValue AS udfv
        INNER JOIN UserDefinedField AS udf ON udfv.FieldID = udf.FieldID
        WHERE udf.FieldLabel = 'Volunteering Interests'
        AND udfv.MemberID IN ($placeholders) AND udfv.ValueText IS NOT NULL
    ");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) {
        if (isset($members[$r[0]])) $members[$r[0]]['volunteeringInterests'][] = $r[1];
    }

    // Batch: current address (display + search)
    $stmt = $db->prepare("
        SELECT ma.MemberID, ma.Street, ma.City, p.ProvinceName, ma.PostalCode
        FROM MemberAddress AS ma
        LEFT JOIN Provinces AS p ON CAST(ma.ProvinceID AS UNSIGNED) = p.ProvinceID
        WHERE ma.MemberID IN ($placeholders) AND ma.IsCurrent = 1
    ");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) {
        $mid = $r[0];
        if (!isset($members[$mid])) continue;
        $display = implode(', ', array_filter([$r[1], $r[2]]));
        $search  = implode(' ',  array_filter([$r[1], $r[2], $r[3], $r[4]]));
        $members[$mid]['address']      = $display;
        $members[$mid]['addressSearch'] = $search;
    }

    // Batch: roles
    $stmt = $db->prepare("
        SELECT mr.MemberID, r.RoleName, fy.YearLabel
        FROM MemberRole AS mr
        LEFT JOIN Role AS r ON mr.RoleID = r.RoleID
        LEFT JOIN FiscalYear AS fy ON mr.FiscalYearID = fy.FiscalYearID
        WHERE mr.MemberID IN ($placeholders) AND r.RoleName IS NOT NULL
        ORDER BY fy.YearLabel DESC
    ");
    $stmt->execute($ids);
    $roles_by_member = [];
    foreach ($stmt->fetchAll() as $r) {
        $mid = $r[0];
        $roles_by_member[$mid][] = $r[1] . ($r[2] ? ' (' . $r[2] . ')' : '');
    }
    foreach ($roles_by_member as $mid => $role_list) {
        if (isset($members[$mid])) {
            $members[$mid]['role'] = implode(', ', array_unique($role_list));
        }
    }

    json_out(array_values($members));
}

// ── Single member ─────────────────────────────────────────────────────────────
function get_member_handler(int $member_id): void {
    require_auth();
    $db   = get_db();

    $stmt = $db->prepare('
        SELECT m.MemberID, m.FirstName, m.LastName,
               m.`Place of Birth`, m.`Date of Birth`,
               m.IsActive, mc.CategoryID, mc.CategoryName,
               m.DateJoined, m.DateEnded, m.ApplicationDate, m.`Approval Date`,
               m.ApprovedBy, m.SignedBy, m.Proposer, m.Seconder, m.ProposalDate,
               m.Email, m.PhoneNumber,
               m.OccupationID, o.OccupationName,
               m.Notes, m.OtherSocieties, m.MemberCategoryID,
               m.CountyID, m.SurnameID
        FROM Members AS m
        LEFT JOIN MemberCategory AS mc ON m.MemberCategoryID = mc.CategoryID
        LEFT JOIN Occupation AS o ON m.OccupationID = o.OccupationID
        WHERE m.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $m = $stmt->fetch();
    if (!$m) json_out(['error' => 'Member not found'], 404);

    // Addresses
    $stmt = $db->prepare('
        SELECT ma.MemberAddressID, ma.Street, ma.City, COALESCE(p.ProvinceName, ma.ProvinceID), ma.PostalCode,
               ma.CountryID, ma.IsCurrent, ma.ProvinceID
        FROM MemberAddress AS ma
        LEFT JOIN Provinces AS p ON ma.ProvinceID = p.ProvinceID
        WHERE ma.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $addresses = [];
    foreach ($stmt->fetchAll() as $a) {
        $addresses[] = [
            'id'         => $a[0],
            'street'     => $a[1] ?? '',
            'city'       => $a[2] ?? '',
            'province'   => $a[3] ?? '',
            'postalCode' => $a[4] ?? '',
            'country'    => $a[5] ?? '',
            'isCurrent'  => (bool)$a[6],
        ];
    }

    // Phone numbers
    $stmt = $db->prepare('SELECT PhoneID, PhoneType, PhoneNumber, IsPreferred FROM MemberPhoneNumbers WHERE MemberID = ?');
    $stmt->execute([$member_id]);
    $phones = [];
    foreach ($stmt->fetchAll() as $p) {
        $phones[] = ['id' => $p[0], 'type' => $p[1], 'number' => $p[2], 'isPreferred' => (bool)$p[3]];
    }

    // Irish connections
    $stmt = $db->prepare('
        SELECT ic.ID, ic.CountyID, ict.CountyName, ic.ConnectionType
        FROM IrishConnectionByCounty AS ic
        LEFT JOIN IrishCounties AS ict ON ic.CountyID = ict.CountyID
        WHERE ic.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $county_conns = [];
    foreach ($stmt->fetchAll() as $ic) {
        $county_conns[] = ['countyId' => $ic[1], 'countyName' => $ic[2], 'type' => $ic[3]];
    }

    $stmt = $db->prepare('
        SELECT ics.SurnameID, isur.Surname, ics.ConnectionType
        FROM IrishConnectionBySurname AS ics
        LEFT JOIN IrishSurnames AS isur ON ics.SurnameID = isur.SurnameID
        WHERE ics.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $surname_conns = [];
    foreach ($stmt->fetchAll() as $sc) {
        $surname_conns[] = ['surnameId' => $sc[0], 'surname' => $sc[1], 'type' => $sc[2]];
    }

    // Merge Irish connections: match by type where possible
    $irish = [];
    foreach ($county_conns as $row) {
        $irish[] = ['type' => $row['type'], 'countyId' => $row['countyId'], 'countyName' => $row['countyName'], 'surnameId' => '', 'surname' => ''];
    }
    foreach ($surname_conns as $row) {
        $matched = false;
        foreach ($irish as &$ic) {
            if ($ic['type'] === $row['type'] && !$ic['surnameId']) {
                $ic['surnameId'] = $row['surnameId'];
                $ic['surname']   = $row['surname'];
                $matched = true;
                break;
            }
        }
        unset($ic);
        if (!$matched) {
            $irish[] = ['type' => $row['type'], 'countyId' => '', 'countyName' => '', 'surnameId' => $row['surnameId'], 'surname' => $row['surname']];
        }
    }
    if (empty($irish)) $irish = [['type' => '', 'countyId' => '', 'surnameId' => '']];

    // Roles
    $stmt = $db->prepare('
        SELECT mr.MemberRoleID, mr.RoleID, r.RoleName, mr.FiscalYearID, fy.YearLabel
        FROM MemberRole AS mr
        LEFT JOIN Role AS r ON mr.RoleID = r.RoleID
        LEFT JOIN FiscalYear AS fy ON mr.FiscalYearID = fy.FiscalYearID
        WHERE mr.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $role_fy = [];
    foreach ($stmt->fetchAll() as $rf) {
        $role_fy[] = ['memberRoleID' => $rf[0], 'roleID' => $rf[1], 'roleName' => $rf[2], 'fiscalYearID' => $rf[3], 'yearLabel' => $rf[4]];
    }

    // Volunteering interests
    $stmt = $db->prepare('
        SELECT udfv.ValueText FROM UserDefinedFieldValue AS udfv
        INNER JOIN UserDefinedField AS udf ON udfv.FieldID = udf.FieldID
        WHERE udf.FieldLabel = \'Volunteering Interests\' AND udfv.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $vi = array_column($stmt->fetchAll(), 0);

    json_out([
        'id'                => $m[0],
        'memberID'          => $m[0],
        'firstName'         => $m[1],
        'lastName'          => $m[2],
        'placeOfBirth'      => $m[3] ?? '',
        'dateOfBirth'       => format_date($m[4]),
        'isActive'          => (bool)($m[5] == 1),
        'memberCategoryID'  => $m[6],
        'category'          => $m[7],
        'dateJoined'        => format_date($m[8]),
        'dateEnded'         => format_date($m[9]),
        'applicationDate'   => format_date($m[10]),
        'approvalDate'      => format_date($m[11]),
        'approvedBy'        => $m[12] ?? '',
        'signedBy'          => $m[13] ?? '',
        'proposer'          => $m[14] ?? '',
        'seconder'          => $m[15] ?? '',
        'proposalDate'      => format_date($m[16]),
        'email'             => $m[17] ?? '',
        'phoneNumber'       => $m[18] ?? '',
        'occupationID'      => $m[19],
        'occupation'        => $m[20] ?? '',
        'notes'             => $m[21] ?? '',
        'otherSocieties'    => $m[22] ?? '',
        'memberCategoryId'  => $m[23],
        'addresses'         => $addresses,
        'phoneNumbers'      => $phones,
        'irishConnections'  => $irish,
        'roleFiscalYears'   => $role_fy,
        'volunteeringInterests' => $vi,
    ]);
}

// ── Create member ─────────────────────────────────────────────────────────────
function create_member_handler(): void {
    require_admin();
    $data = get_body();
    if (!$data) json_out(['error' => 'Invalid input'], 400);

    $first = trim($data['firstName'] ?? '');
    $last  = trim($data['lastName']  ?? '');
    if (!$first || !$last) json_out(['error' => 'First and last name required'], 400);

    $db  = get_db();

    // Duplicate check
    $email    = trim($data['email']       ?? '') ?: null;
    $phone    = trim($data['phoneNumber'] ?? '') ?: null;
    $dob      = to_date($data['dateOfBirth'] ?? null);
    $lib_email = 'bisofpeilibrary@gmail.com';
    if ($email === $lib_email) $email = null;

    $dup = null;
    if ($email) {
        $s = $db->prepare('SELECT MemberID FROM Members WHERE FirstName = ? AND LastName = ? AND Email = ?');
        $s->execute([$first, $last, $email]);
        if ($s->fetch()) $dup = "A member named $first $last with that email already exists.";
    }
    if (!$dup && $phone) {
        $s = $db->prepare('SELECT MemberID FROM Members WHERE FirstName = ? AND LastName = ? AND PhoneNumber = ?');
        $s->execute([$first, $last, $phone]);
        if ($s->fetch()) $dup = "A member named $first $last with that phone number already exists.";
    }
    if (!$dup && $dob) {
        $s = $db->prepare('SELECT MemberID FROM Members WHERE FirstName = ? AND LastName = ? AND `Date of Birth` = ?');
        $s->execute([$first, $last, $dob]);
        if ($s->fetch()) $dup = "A member named $first $last with that date of birth already exists.";
    }
    if (!$dup && !$email && !$phone && !$dob) {
        $s = $db->prepare('SELECT MemberID FROM Members WHERE FirstName = ? AND LastName = ?');
        $s->execute([$first, $last]);
        if ($s->fetch()) $dup = "A member named $first $last already exists. Provide email, phone, or date of birth to confirm this is a different person.";
    }
    if ($dup) json_out(['error' => 'duplicate', 'message' => $dup], 409);

    // Derive IsActive from category
    $cat_id   = to_int($data['memberCategoryId'] ?? null);
    $is_active = true;
    if ($cat_id) {
        $s = $db->prepare('SELECT CategoryName FROM MemberCategory WHERE CategoryID = ?');
        $s->execute([$cat_id]);
        $cat = $s->fetch();
        if ($cat) $is_active = in_array(strtolower($cat[0]), ['active', 'honorary']);
    }

    $date_joined = to_date($data['dateJoined'] ?? null); // Allow null for DateJoined

    // Other societies list → comma string
    $other_soc = $data['otherSocieties'] ?? null;
    if (is_array($other_soc)) $other_soc = implode(', ', array_filter($other_soc)) ?: null;

    $db->prepare('
        INSERT INTO Members (
            FirstName, LastName, Email, PhoneNumber,
            `Place of Birth`, `Date of Birth`, MemberCategoryID,
            OccupationID, Notes, IsActive, OtherSocieties,
            DateJoined, DateEnded, ApplicationDate, `Approval Date`,
            ApprovedBy, SignedBy, Proposer, Seconder, ProposalDate, CreatedAt
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())
    ')->execute([
        $first,
        $last,
        $data['email'] ?? null,
        $phone,
        $data['placeOfBirth'] ?? null,
        $dob,
        $cat_id,
        to_int($data['occupationId'] ?? null),
        $data['notes'] ?? '',
        $is_active ? 1 : 0,
        $other_soc,
        $date_joined,
        to_date($data['dateEnded']       ?? null),
        to_date($data['applicationDate'] ?? null),
        to_date($data['approvalDate']    ?? null),
        $data['approvedBy']  ?? null,
        $data['signedBy']    ?? null,
        $data['proposer']    ?? null,
        $data['seconder']    ?? null,
        to_date($data['proposalDate'] ?? null),
    ]);
    $member_id = (int)$db->lastInsertId();

    _save_member_related($db, $member_id, $data);

    json_out(['success' => true, 'member_id' => $member_id], 201);
}

// ── Update member ─────────────────────────────────────────────────────────────
function update_member_handler(int $member_id): void {
    require_admin();
    $data = get_body();
    if (!$data) json_out(['error' => 'Invalid input'], 400);

    $db = get_db();
    $s = $db->prepare('SELECT MemberID FROM Members WHERE MemberID = ?');
    $s->execute([$member_id]);
    if (!$s->fetch()) json_out(['error' => 'Member not found'], 404);

    $cat_id    = to_int($data['memberCategoryId'] ?? null);
    $is_active = true;
    if ($cat_id) {
        $s = $db->prepare('SELECT CategoryName FROM MemberCategory WHERE CategoryID = ?');
        $s->execute([$cat_id]);
        $cat = $s->fetch();
        if ($cat) $is_active = in_array(strtolower($cat[0]), ['active', 'honorary']);
    }

    $other_soc = $data['otherSocieties'] ?? null;
    if (is_array($other_soc)) $other_soc = implode(', ', array_filter($other_soc)) ?: null;

    $db->prepare('
        UPDATE Members SET
            FirstName = ?, LastName = ?, Email = ?, PhoneNumber = ?,
            `Place of Birth` = ?, `Date of Birth` = ?, MemberCategoryID = ?,
            OccupationID = ?, Notes = ?, IsActive = ?, OtherSocieties = ?,
            DateJoined = ?, DateEnded = ?, ApplicationDate = ?, `Approval Date` = ?,
            ApprovedBy = ?, SignedBy = ?, Proposer = ?, Seconder = ?, ProposalDate = ?
        WHERE MemberID = ?
    ')->execute([
        trim($data['firstName'] ?? ''),
        trim($data['lastName']  ?? ''),
        $data['email']       ?? null,
        $data['phoneNumber'] ?? null,
        $data['placeOfBirth'] ?? null,
        to_date($data['dateOfBirth']    ?? null),
        $cat_id,
        to_int($data['occupationId']   ?? null),
        $data['notes']       ?? '',
        $is_active ? 1 : 0,
        $other_soc,
        to_date($data['dateJoined']      ?? null),
        to_date($data['dateEnded']       ?? null),
        to_date($data['applicationDate'] ?? null),
        to_date($data['approvalDate']    ?? null),
        $data['approvedBy']  ?? null,
        $data['signedBy']    ?? null,
        $data['proposer']    ?? null,
        $data['seconder']    ?? null,
        to_date($data['proposalDate']    ?? null),
        $member_id,
    ]);

    _delete_member_related($db, $member_id);
    _save_member_related($db, $member_id, $data);

    json_out(['success' => true]);
}

// ── Deactivate / Reinstate / Delete ──────────────────────────────────────────
function deactivate_member_handler(int $member_id): void {
    require_admin();
    $db = get_db();
    $db->prepare("UPDATE Members SET IsActive = 0 WHERE MemberID = ?")->execute([$member_id]);
    json_out(['success' => true]);
}

function reinstate_member_handler(int $member_id): void {
    require_admin();
    $db = get_db();
    $db->prepare("UPDATE Members SET IsActive = 1 WHERE MemberID = ?")->execute([$member_id]);
    json_out(['success' => true]);
}

function delete_member_handler(int $member_id): void {
    require_admin();
    $db = get_db();
    $db->prepare("UPDATE Members SET IsActive = 0 WHERE MemberID = ?")->execute([$member_id]);
    json_out(['success' => true]);
}

function bulk_deactivate_handler(): void {
    require_admin();
    $data = get_body();
    $ids  = $data['memberIds'] ?? $data['member_ids'] ?? [];
    if (!is_array($ids) || empty($ids)) json_out(['error' => 'No member IDs provided'], 400);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $db = get_db();
    $db->prepare("UPDATE Members SET IsActive = 0 WHERE MemberID IN ($ph)")->execute($ids);
    json_out(['success' => true, 'count' => count($ids)]);
}

// ── Shared helpers ────────────────────────────────────────────────────────────
function _delete_member_related(PDO $db, int $member_id): void {
    $db->prepare('DELETE FROM MemberAddress WHERE MemberID = ?')->execute([$member_id]);
    $db->prepare('DELETE FROM IrishConnectionByCounty WHERE MemberID = ?')->execute([$member_id]);
    $db->prepare('DELETE FROM IrishConnectionBySurname WHERE MemberID = ?')->execute([$member_id]);
    $db->prepare('DELETE FROM MemberRole WHERE MemberID = ?')->execute([$member_id]);
    $db->prepare('DELETE FROM MemberPhoneNumbers WHERE MemberID = ?')->execute([$member_id]);
    $fid = _get_volunteering_field_id($db);
    if ($fid) $db->prepare('DELETE FROM UserDefinedFieldValue WHERE FieldID = ? AND MemberID = ?')->execute([$fid, $member_id]);
}

function _save_member_related(PDO $db, int $member_id, array $data): void {
    // Addresses
    foreach ($data['addresses'] ?? [] as $addr) {
        $has_data = array_filter([$addr['street'] ?? '', $addr['city'] ?? '', $addr['province'] ?? '', $addr['country'] ?? '', $addr['postalCode'] ?? '']);
        if (!$has_data) continue;
        $prov_id = null;
        if (!empty($addr['province'])) {
            $s = $db->prepare('SELECT ProvinceID FROM Provinces WHERE LOWER(ProvinceName) = LOWER(?)');
            $s->execute([$addr['province']]);
            $row = $s->fetch();
            $prov_id = $row ? $row[0] : null;
        }
        $db->prepare('
            INSERT INTO MemberAddress (MemberID, Street, City, ProvinceID, CountryID, PostalCode, IsCurrent)
            VALUES (?,?,?,?,?,?,?)
        ')->execute([
            $member_id,
            $addr['street']     ?? null,
            $addr['city']       ?? null,
            $prov_id,
            $addr['country']    ?? null,
            $addr['postalCode'] ?? null,
            ($addr['isCurrent'] ?? false) ? 1 : 0,
        ]);
    }

    // Irish connections
    foreach ($data['irishConnections'] ?? [] as $ic) {
        $county_id  = to_int($ic['countyId']  ?? null);
        $surname_id = to_int($ic['surnameId'] ?? null);
        $type       = $ic['type'] ?? 'Paternal';
        if ($county_id) {
            $db->prepare('INSERT INTO IrishConnectionByCounty (MemberID, CountyID, ConnectionType) VALUES (?,?,?)')->execute([$member_id, $county_id, $type]);
        }
        if ($surname_id) {
            $db->prepare('INSERT INTO IrishConnectionBySurname (MemberID, SurnameID, ConnectionType) VALUES (?,?,?)')->execute([$member_id, $surname_id, $type]);
        }
    }

    // Role / Fiscal Year
    foreach ($data['roleFiscalYears'] ?? [] as $rf) {
        $role_id = to_int($rf['role'] ?? $rf['roleID'] ?? null);
        $fy_id   = to_int($rf['fiscalYear'] ?? $rf['fiscalYearID'] ?? null);
        if ($role_id && $fy_id) {
            $db->prepare('INSERT INTO MemberRole (MemberID, RoleID, FiscalYearID) VALUES (?,?,?)')->execute([$member_id, $role_id, $fy_id]);
        }
    }

    // Phone numbers
    $valid_types = ['Home', 'Cell', 'Work', 'Other'];
    foreach ($data['phoneNumbers'] ?? [] as $ph) {
        $type   = $ph['type']   ?? 'Other';
        $number = $ph['number'] ?? '';
        if ($number && in_array($type, $valid_types)) {
            $db->prepare('INSERT INTO MemberPhoneNumbers (MemberID, PhoneType, PhoneNumber, IsPreferred) VALUES (?,?,?,?)')->execute([
                $member_id, $type, $number, ($ph['isPreferred'] ?? false) ? 1 : 0,
            ]);
        }
    }

    // Volunteering interests
    $fid = _get_volunteering_field_id($db);
    if ($fid) {
        foreach ($data['volunteeringInterests'] ?? [] as $interest) {
            if ($interest) {
                $db->prepare('INSERT INTO UserDefinedFieldValue (FieldID, MemberID, ValueText) VALUES (?,?,?)')->execute([$fid, $member_id, $interest]);
            }
        }
    }
}

function _get_volunteering_field_id(PDO $db): ?int {
    static $fid = false;
    if ($fid === false) {
        $s = $db->prepare("SELECT FieldID FROM UserDefinedField WHERE FieldLabel = 'Volunteering Interests'");
        $s->execute();
        $row = $s->fetch();
        $fid = $row ? (int)$row[0] : null;
    }
    return $fid;
}
