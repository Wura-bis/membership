<?php
function handle_login(): void {
    $data = get_body();
    $username = trim($data['username'] ?? '');
    $password = $data['password'] ?? '';
    if (!$username || !$password) json_out(['error' => 'Username and password required'], 400);

    $db = get_db();
    $hashed = hash_password($password);

    $stmt = $db->prepare('
        SELECT UserID, Username, Email, Role, IsApproved, FirstName, `Last Name`
        FROM User
        WHERE (Username = ? OR Email = ?) AND PasswordHash = ?
    ');
    $stmt->execute([$username, $username, $hashed]);
    $user = $stmt->fetch();

    if (!$user) json_out(['error' => 'Invalid username or password'], 401);

    [$uid, $uname, $email, $role, $is_approved, $first, $last] = $user;
    $role = strtolower((string)$role);
    $is_approved = (int)$is_approved;

    // Determine effective role
    $effective_role = $role;
    if ($role === 'private' && $is_approved === 0) $effective_role = 'public';
    if ($role === 'admin'   && $is_approved === 0) json_out(['error' => 'Account pending approval'], 403);

    // Update last login
    $db->prepare('UPDATE User SET LastLogin = NOW() WHERE UserID = ?')->execute([$uid]);

    $_SESSION['user'] = [
        'id'        => $uid,
        'username'  => $uname,
        'email'     => $email,
        'role'      => $effective_role,
        'firstName' => $first,
        'lastName'  => $last,
    ];

    json_out([
        'success'   => true,
        'user_id'   => $uid,
        'username'  => $uname,
        'email'     => $email,
        'role'      => $effective_role,
        'firstName' => $first,
        'lastName'  => $last,
    ]);
}

function handle_logout(): void {
    session_destroy();
    json_out(['success' => true]);
}

function handle_check_auth(): void {
    if (empty($_SESSION['user'])) json_out(['authenticated' => false], 401);
    $u = $_SESSION['user'];
    json_out([
        'authenticated' => true,
        'user_id'       => $u['id'],
        'username'      => $u['username'],
        'email'         => $u['email'],
        'role'          => $u['role'],
        'firstName'     => $u['firstName'],
        'lastName'      => $u['lastName'],
    ]);
}

function handle_signup(): void {
    $data = get_body();
    $username  = trim($data['username']  ?? '');
    $email     = trim($data['email']     ?? '');
    $password  = $data['password']  ?? '';
    $first     = trim($data['firstName'] ?? '');
    $last      = trim($data['lastName']  ?? '');
    $role      = $data['role'] ?? 'public';

    if (!$username || !$email || !$password) {
        json_out(['error' => 'Username, email and password are required'], 400);
    }

    $allowed_roles = ['public', 'private'];
    if (!in_array(strtolower($role), $allowed_roles)) $role = 'public';

    $db = get_db();
    $stmt = $db->prepare('SELECT UserID FROM User WHERE Username = ? OR Email = ?');
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) json_out(['error' => 'Username or email already exists'], 409);

    $hashed = hash_password($password);
    $is_approved = ($role === 'public') ? 1 : 0;

    $db->prepare('
        INSERT INTO User (Username, Email, PasswordHash, Role, IsApproved, FirstName, `Last Name`, CreatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ')->execute([$username, $email, $hashed, $role, $is_approved, $first, $last]);

    json_out(['success' => true], 201);
}

function handle_forgot_password(): void {
    // Without email infrastructure, just return a generic response
    json_out(['success' => true, 'message' => 'If that account exists, a reset link has been sent.']);
}

function handle_reset_password(): void {
    $data = get_body();
    $token    = $data['token']    ?? '';
    $password = $data['password'] ?? '';
    if (!$token || !$password) json_out(['error' => 'Token and password required'], 400);

    $db = get_db();
    $stmt = $db->prepare('SELECT UserID FROM User WHERE ResetToken = ? AND ResetTokenExpiry > NOW()');
    $stmt->execute([$token]);
    $row = $stmt->fetch();
    if (!$row) json_out(['error' => 'Invalid or expired token'], 400);

    $hashed = hash_password($password);
    $db->prepare('UPDATE User SET PasswordHash = ?, ResetToken = NULL, ResetTokenExpiry = NULL WHERE UserID = ?')
       ->execute([$hashed, $row[0]]);
    json_out(['success' => true]);
}

function handle_reset_password_noemail(): void {
    $data = get_body();
    $user_id  = $data['userID']   ?? $data['userId']   ?? '';
    $password = $data['password'] ?? '';
    if (!$user_id || !$password) json_out(['error' => 'UserID and password required'], 400);

    $db = get_db();
    $stmt = $db->prepare('SELECT UserID FROM User WHERE UserID = ?');
    $stmt->execute([$user_id]);
    if (!$stmt->fetch()) json_out(['error' => 'User not found'], 404);

    $hashed = hash_password($password);
    $db->prepare('UPDATE User SET PasswordHash = ? WHERE UserID = ?')->execute([$hashed, $user_id]);
    json_out(['success' => true]);
}

function handle_my_profile_get(): void {
    $u = require_auth();
    $db = get_db();
    $stmt = $db->prepare('SELECT UserID, Username, Email, Role, FirstName, `Last Name`, CreatedAt, LastLogin FROM User WHERE UserID = ?');
    $stmt->execute([$u['id']]);
    $row = $stmt->fetch();
    if (!$row) json_out(['error' => 'User not found'], 404);

    json_out([
        'id'        => $row[0],
        'username'  => $row[1],
        'email'     => $row[2],
        'role'      => $row[3],
        'firstName' => $row[4],
        'lastName'  => $row[5],
        'createdAt' => format_date($row[6]),
        'lastLogin' => $row[7] ? substr((string)$row[7], 0, 19) : null,
    ]);
}

function handle_my_profile_put(): void {
    $u    = require_auth();
    $data = get_body();
    $db   = get_db();

    $first = trim($data['firstName'] ?? '');
    $last  = trim($data['lastName']  ?? '');
    $email = trim($data['email']     ?? '');

    $db->prepare('UPDATE User SET FirstName = ?, `Last Name` = ?, Email = ? WHERE UserID = ?')
       ->execute([$first, $last, $email, $u['id']]);

    $_SESSION['user']['firstName'] = $first;
    $_SESSION['user']['lastName']  = $last;
    $_SESSION['user']['email']     = $email;

    json_out(['success' => true]);
}

function handle_change_password(): void {
    $u    = require_auth();
    $data = get_body();
    $current  = $data['currentPassword'] ?? $data['current_password'] ?? '';
    $new_pass = $data['newPassword']      ?? $data['new_password']      ?? '';

    if (!$current || !$new_pass) json_out(['error' => 'Current and new password required'], 400);

    $db = get_db();
    $stmt = $db->prepare('SELECT PasswordHash FROM User WHERE UserID = ?');
    $stmt->execute([$u['id']]);
    $row = $stmt->fetch();

    if (!$row || $row[0] !== hash_password($current)) {
        json_out(['error' => 'Current password is incorrect'], 400);
    }

    $db->prepare('UPDATE User SET PasswordHash = ? WHERE UserID = ?')
       ->execute([hash_password($new_pass), $u['id']]);
    json_out(['success' => true]);
}

function handle_request_private_access(): void {
    $u  = require_auth();
    $db = get_db();
    $db->prepare("UPDATE User SET Role = 'private', IsApproved = 0 WHERE UserID = ?")->execute([$u['id']]);
    json_out(['success' => true]);
}
