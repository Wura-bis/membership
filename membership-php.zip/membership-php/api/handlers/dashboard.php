<?php
function dashboard_stats_handler(): void {
    $db = get_db();

    $total = (int)$db->query('SELECT COUNT(*) FROM Members')->fetchColumn();

    $cats   = ['Active', 'Inactive', 'Honorary', 'Historical'];
    $counts = [];
    foreach ($cats as $cat) {
        $s = $db->prepare('SELECT COUNT(*) FROM Members m INNER JOIN MemberCategory mc ON m.MemberCategoryID = mc.CategoryID WHERE mc.CategoryName = ?');
        $s->execute([$cat]);
        $counts[$cat] = (int)$s->fetchColumn();
    }

    $month_start = date('Y-m-01');
    $s = $db->prepare('SELECT COUNT(*) FROM Members WHERE DateJoined >= ?');
    $s->execute([$month_start]);
    $new_this_month = (int)$s->fetchColumn();

    json_out([
        'totalMembers'     => $total,
        'activeMembers'    => $counts['Active'],
        'inactiveMembers'  => $counts['Inactive'],
        'honoraryMembers'  => $counts['Honorary'],
        'historicalMembers'=> $counts['Historical'],
        'newThisMonth'     => $new_this_month,
    ]);
}

function dashboard_handler(): void {
    require_private_or_admin();
    $db = get_db();

    $active   = (int)$db->query("SELECT COUNT(*) FROM Members WHERE IsActive = 1")->fetchColumn();
    $inactive = (int)$db->query("SELECT COUNT(*) FROM Members WHERE IsActive = 0")->fetchColumn();

    $total_soc = 0;
    try { $total_soc = (int)$db->query('SELECT COUNT(*) FROM Society')->fetchColumn(); } catch(Exception $e) {}

    $active_users    = (int)$db->query("SELECT COUNT(*) FROM User WHERE IsApproved = 1")->fetchColumn();
    $pending_approvals = (int)$db->query("SELECT COUNT(*) FROM User WHERE IsApproved = 0")->fetchColumn();

    $thirty_ago = date('Y-m-d', strtotime('-30 days'));
    $s = $db->prepare('SELECT COUNT(*) FROM Members WHERE DateJoined >= ?');
    $s->execute([$thirty_ago]);
    $recent = (int)$s->fetchColumn();

    // Members by category
    $cats = $db->query('SELECT mc.CategoryName, COUNT(m.MemberID) as cnt FROM MemberCategory mc LEFT JOIN Members m ON mc.CategoryID = m.MemberCategoryID WHERE m.IsActive = 1 GROUP BY mc.CategoryName ORDER BY cnt DESC')->fetchAll();
    $by_cat = array_map(fn($r) => ['name' => $r[0], 'count' => (int)$r[1]], $cats);

    // Members by province
    $provs = $db->query('SELECT p.ProvinceName, p.CountryName, p.CountryCode, COUNT(DISTINCT m.MemberID) as cnt FROM MemberAddress ma JOIN Members m ON ma.MemberID = m.MemberID JOIN Provinces p ON CAST(ma.ProvinceID AS UNSIGNED) = p.ProvinceID WHERE ma.IsCurrent = 1 AND m.IsActive = 1 GROUP BY p.ProvinceName, p.CountryName, p.CountryCode ORDER BY cnt DESC')->fetchAll();
    $by_prov = array_map(fn($r) => ['province' => $r[0], 'country' => $r[1], 'countryCode' => $r[2], 'count' => (int)$r[3]], $provs);

    // Recent activity
    $recent_stmt = $db->query('SELECT CONCAT(m.FirstName, \' \', m.LastName), m.DateJoined, m.MemberID FROM Members m WHERE m.DateJoined IS NOT NULL ORDER BY m.DateJoined DESC LIMIT 10');
    $activity = [];
    foreach ($recent_stmt->fetchAll() as $r) {
        $activity[] = ['name' => $r[0], 'date' => format_date($r[1]), 'activity' => 'New Member', 'id' => $r[2]];
    }

    json_out([
        'stats' => [
            'activeMembers'    => $active,
            'inactiveMembers'  => $inactive,
            'totalSocieties'   => $total_soc,
            'activeUsers'      => $active_users,
            'recentMembers'    => $recent,
            'pendingApprovals' => $pending_approvals,
        ],
        'charts' => [
            'membersByCategory' => $by_cat,
            'membersByProvince' => $by_prov,
            'membershipGrowth'  => [],
        ],
        'recentActivity' => $activity,
    ]);
}
