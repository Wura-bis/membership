<?php
function _member_csv_row(array $m): array {
    return [
        $m[0], $m[1], $m[2],                         // ID, First, Last
        $m[4] ? format_date($m[4]) : '',              // DOB
        $m[3] ?? '',                                  // Place of Birth
        $m[9]  ?? '',                                 // Email
        $m[10] ?? '',                                 // Phone
        $m[6]  ?? '',                                 // Category
        $m[8]  ? format_date($m[8]) : '',             // Date Joined
        $m[5] == 1 ? 'Active' : 'Inactive',           // Status
        $m[11] ?? '',                                 // Approved By
        $m[12] ?? '',                                 // Signed By
        $m[13] ?? '',                                 // Proposer
        $m[14] ?? '',                                 // Seconder
    ];
}

function _stream_csv(string $filename, array $headers, array $rows): void {
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header('Pragma: no-cache');
    $out = fopen('php://output', 'w');
    fputcsv($out, $headers);
    foreach ($rows as $row) fputcsv($out, $row);
    fclose($out);
    exit;
}

function export_all_members_csv(): void {
    require_private_or_admin();
    $db   = get_db();
    $stmt = $db->query('
        SELECT m.MemberID, m.FirstName, m.LastName,
               m.`Place of Birth`, m.`Date of Birth`,
               m.IsActive, mc.CategoryName,
               m.DateJoined, m.DateEnded,
               m.Email, m.PhoneNumber,
               m.ApprovedBy, m.SignedBy, m.Proposer, m.Seconder
        FROM Members m
        LEFT JOIN MemberCategory mc ON m.MemberCategoryID = mc.CategoryID
        ORDER BY m.LastName, m.FirstName
    ');
    $rows = [];
    foreach ($stmt->fetchAll() as $r) $rows[] = _member_csv_row($r);

    _stream_csv('members.csv', ['ID','First Name','Last Name','Date of Birth','Place of Birth','Email','Phone','Category','Date Joined','Status','Approved By','Signed By','Proposer','Seconder'], $rows);
}

function export_member_csv(int $member_id): void {
    require_private_or_admin();
    $db   = get_db();
    $stmt = $db->prepare('
        SELECT m.MemberID, m.FirstName, m.LastName,
               m.`Place of Birth`, m.`Date of Birth`,
               m.IsActive, mc.CategoryName,
               m.DateJoined, m.DateEnded,
               m.Email, m.PhoneNumber,
               m.ApprovedBy, m.SignedBy, m.Proposer, m.Seconder,
               o.OccupationName, m.Notes, m.OtherSocieties
        FROM Members m
        LEFT JOIN MemberCategory mc ON m.MemberCategoryID = mc.CategoryID
        LEFT JOIN Occupation o ON m.OccupationID = o.OccupationID
        WHERE m.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $m = $stmt->fetch();
    if (!$m) { http_response_code(404); echo 'Not found'; exit; }

    $headers = ['Field','Value'];
    $rows    = [
        ['Member ID',     $m[0]],
        ['First Name',    $m[1]],
        ['Last Name',     $m[2]],
        ['Date of Birth', format_date($m[4])],
        ['Place of Birth',$m[3] ?? ''],
        ['Email',         $m[9] ?? ''],
        ['Phone',         $m[10] ?? ''],
        ['Category',      $m[6] ?? ''],
        ['Date Joined',   format_date($m[7])],
        ['Date Ended',    format_date($m[8])],
        ['Status',        $m[5] == 1 ? 'Active' : 'Inactive'],
        ['Occupation',    $m[15] ?? ''],
        ['Approved By',   $m[11] ?? ''],
        ['Signed By',     $m[12] ?? ''],
        ['Proposer',      $m[13] ?? ''],
        ['Seconder',      $m[14] ?? ''],
        ['Other Societies',$m[17] ?? ''],
        ['Notes',         $m[16] ?? ''],
    ];

    // Addresses
    $astmt = $db->prepare('SELECT Street, City, ProvinceID, PostalCode, CountryID, IsCurrent FROM MemberAddress WHERE MemberID = ?');
    $astmt->execute([$member_id]);
    foreach ($astmt->fetchAll() as $i => $a) {
        $rows[] = ["Address " . ($i+1), implode(', ', array_filter([$a[0], $a[1], $a[3], $a[4]])) . ($a[5] ? ' (current)' : '')];
    }

    // Phone numbers
    $pstmt = $db->prepare('SELECT PhoneType, PhoneNumber FROM MemberPhoneNumbers WHERE MemberID = ?');
    $pstmt->execute([$member_id]);
    foreach ($pstmt->fetchAll() as $p) {
        $rows[] = [$p[0] . ' Phone', $p[1]];
    }

    _stream_csv("member_{$member_id}.csv", $headers, $rows);
}

function export_member_pdf(int $member_id): void {
    // Simple HTML-to-response PDF substitute — generates an HTML page the browser can print/save as PDF
    require_private_or_admin();
    $db   = get_db();
    $stmt = $db->prepare('
        SELECT m.MemberID, m.FirstName, m.LastName,
               m.`Place of Birth`, m.`Date of Birth`,
               m.IsActive, mc.CategoryName,
               m.DateJoined, m.DateEnded,
               m.Email, m.PhoneNumber,
               m.ApprovedBy, m.SignedBy, m.Proposer, m.Seconder,
               o.OccupationName, m.Notes, m.OtherSocieties
        FROM Members m
        LEFT JOIN MemberCategory mc ON m.MemberCategoryID = mc.CategoryID
        LEFT JOIN Occupation o ON m.OccupationID = o.OccupationID
        WHERE m.MemberID = ?
    ');
    $stmt->execute([$member_id]);
    $m = $stmt->fetch();
    if (!$m) { http_response_code(404); echo 'Not found'; exit; }

    header('Content-Type: text/html; charset=utf-8');
    $name = htmlspecialchars($m[1] . ' ' . $m[2]);
    echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>$name</title>
    <style>body{font-family:Arial,sans-serif;margin:40px}h1{color:#0f766e}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:8px 12px}th{background:#f0fdfa;text-align:left}@media print{body{margin:10px}}</style>
    </head><body><h1>BIS Member Profile</h1><h2>$name</h2><table>";

    $fields = [
        'Member ID' => $m[0], 'Date of Birth' => format_date($m[4]),
        'Place of Birth' => $m[3], 'Email' => $m[9], 'Phone' => $m[10],
        'Category' => $m[6], 'Date Joined' => format_date($m[7]),
        'Date Ended' => format_date($m[8]), 'Status' => ($m[5] == 1 ? 'Active' : 'Inactive'),
        'Occupation' => $m[15], 'Approved By' => $m[11], 'Signed By' => $m[12],
        'Proposer' => $m[13], 'Seconder' => $m[14],
        'Other Societies' => $m[17], 'Notes' => $m[16],
    ];
    foreach ($fields as $label => $value) {
        $v = htmlspecialchars((string)($value ?? ''));
        echo "<tr><th>$label</th><td>$v</td></tr>";
    }
    echo '</table><script>window.print()</script></body></html>';
    exit;
}

function export_all_members_pdf(): void {
    // Redirect to CSV — full PDF library not included
    export_all_members_csv();
}

function export_fiscal_year_csv(): void {
    require_private_or_admin();
    $fy = $_GET['fiscalYear'] ?? '';
    $db = get_db();

    $sql = '
        SELECT DISTINCT m.MemberID, m.FirstName, m.LastName, mc.CategoryName,
               m.DateJoined, m.IsActive, r.RoleName, fy.YearLabel
        FROM Members m
        LEFT JOIN MemberCategory mc ON m.MemberCategoryID = mc.CategoryID
        LEFT JOIN MemberRole mr ON m.MemberID = mr.MemberID
        LEFT JOIN Role r ON mr.RoleID = r.RoleID
        LEFT JOIN FiscalYear fy ON mr.FiscalYearID = fy.FiscalYearID
    ';
    $params = [];
    if ($fy) {
        $sql .= ' WHERE fy.YearLabel = ?';
        $params[] = $fy;
    }
    $sql .= ' ORDER BY m.LastName, m.FirstName';

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = [];
    foreach ($stmt->fetchAll() as $r) {
        $rows[] = [$r[0], $r[1], $r[2], $r[3], format_date($r[4]), $r[5] == 1 ? 'Active' : 'Inactive', $r[6], $r[7]];
    }
    _stream_csv("members_fiscal_year.csv", ['ID','First Name','Last Name','Category','Date Joined','Status','Role','Fiscal Year'], $rows);
}

function export_recognitions_csv(): void {
    require_private_or_admin();
    $db   = get_db();
    $stmt = $db->query('
        SELECT mr.RecognitionID, m.FirstName, m.LastName, rt.Name, mr.Notes
        FROM MemberRecognitions mr
        LEFT JOIN Members m ON mr.MemberID = m.MemberID
        LEFT JOIN RecognitionTypes rt ON mr.RecognitionTypeID = rt.RecognitionTypeID
        WHERE mr.IsActive = 1
        ORDER BY m.LastName, m.FirstName
    ');
    $rows = [];
    foreach ($stmt->fetchAll() as $r) {
        $rows[] = [$r[0], $r[1], $r[2], $r[3], $r[4]];
    }
    _stream_csv('recognitions.csv', ['ID','First Name','Last Name','Recognition','Notes'], $rows);
}
