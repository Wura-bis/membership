<?php
// Column name aliases → canonical field name
const COL_MAP = [
    'firstname'        => 'firstName',  'first name'        => 'firstName',  'first'  => 'firstName',
    'lastname'         => 'lastName',   'last name'          => 'lastName',   'last'   => 'lastName',
    'email'            => 'email',      'email address'      => 'email',
    'phone'            => 'phoneNumber','telephone'          => 'phoneNumber','phonenumber' => 'phoneNumber',
    'home'             => 'homePhone',  'home phone'         => 'homePhone',
    'cell'             => 'cellPhone',  'cell phone'         => 'cellPhone',  'mobile' => 'cellPhone',
    'dateofbirth'      => 'dateOfBirth','date of birth'      => 'dateOfBirth','dob'    => 'dateOfBirth','birth date' => 'dateOfBirth',
    'placeofbirth'     => 'placeOfBirth','place of birth'   => 'placeOfBirth',
    'datejoined'       => 'dateJoined', 'date joined'        => 'dateJoined', 'joined' => 'dateJoined',
    'dateended'        => 'dateEnded',  'date ended'         => 'dateEnded',  'ended'  => 'dateEnded',
    'category'         => 'category',   'membercategory'     => 'category',   'member category' => 'category',
    'county'           => 'county',     'irishcounty'        => 'county',     'irish county'    => 'county',
    'surname'          => 'irishSurname','irish surname'     => 'irishSurname',
    'connectiontype'   => 'connectionType','connection type' => 'connectionType','irish connection' => 'connectionType',
    'occupation'       => 'occupation',
    'notes'            => 'notes',
    'isactive'         => 'isActive',   'active'             => 'isActive',   'status' => 'isActive',
    'approvedby'       => 'approvedBy', 'approved by'        => 'approvedBy',
    'signedby'         => 'signedBy',   'signed by'          => 'signedBy',
    'proposer'         => 'proposer',
    'seconder'         => 'seconder',
    'othersocieties'   => 'otherSocieties','other societies' => 'otherSocieties',
];

const LIBRARY_EMAIL = 'bisofpeilibrary@gmail.com';

function _parse_csv_date(?string $v): ?string {
    if (!$v || trim($v) === '') return null;
    $v = trim($v);
    foreach (['Y-m-d','d/m/Y','m/d/Y','d-m-Y','Y/m/d'] as $fmt) {
        $dt = DateTime::createFromFormat($fmt, $v);
        if ($dt) return $dt->format('Y-m-d');
    }
    $ts = strtotime($v);
    return $ts !== false ? date('Y-m-d', $ts) : null;
}

function _map_headers(array $headers): array {
    $map = [];
    foreach ($headers as $i => $h) {
        $key = strtolower(trim($h));
        if (isset(COL_MAP[$key])) $map[COL_MAP[$key]] = $i;
    }
    return $map;
}

function _col(?int $idx, array $row): string {
    if ($idx === null) return '';
    return trim($row[$idx] ?? '');
}

function _find_duplicate(PDO $db, string $first, string $last, ?string $email, ?string $phone, ?string $dob): ?int {
    if ($email && $email !== LIBRARY_EMAIL) {
        $s = $db->prepare('SELECT MemberID FROM Members WHERE TRIM(FirstName)=? AND TRIM(LastName)=? AND Email=?');
        $s->execute([$first, $last, $email]);
        $r = $s->fetch(); if ($r) return (int)$r[0];
    }
    if ($phone) {
        $s = $db->prepare('SELECT MemberID FROM Members WHERE TRIM(FirstName)=? AND TRIM(LastName)=? AND PhoneNumber=?');
        $s->execute([$first, $last, $phone]);
        $r = $s->fetch(); if ($r) return (int)$r[0];
    }
    if ($dob) {
        $s = $db->prepare('SELECT MemberID FROM Members WHERE TRIM(FirstName)=? AND TRIM(LastName)=? AND `Date of Birth`=?');
        $s->execute([$first, $last, $dob]);
        $r = $s->fetch(); if ($r) return (int)$r[0];
    }
    // Name-only — only if exactly one match
    $s = $db->prepare('SELECT MemberID FROM Members WHERE TRIM(FirstName)=? AND TRIM(LastName)=?');
    $s->execute([$first, $last]);
    $all = $s->fetchAll();
    if (count($all) === 1) return (int)$all[0][0];
    return null;
}

function _resolve_category(PDO $db, string $name): ?int {
    if (!$name) return null;
    $s = $db->prepare('SELECT CategoryID FROM MemberCategory WHERE LOWER(CategoryName)=LOWER(?)');
    $s->execute([$name]);
    $r = $s->fetch(); return $r ? (int)$r[0] : null;
}

function _resolve_county(PDO $db, string $name): ?int {
    if (!$name) return null;
    $s = $db->prepare('SELECT CountyID FROM IrishCounties WHERE LOWER(CountyName)=LOWER(?)');
    $s->execute([$name]);
    $r = $s->fetch(); return $r ? (int)$r[0] : null;
}

function _resolve_surname(PDO $db, string $name): ?int {
    if (!$name) return null;
    $s = $db->prepare('SELECT SurnameID FROM IrishSurnames WHERE LOWER(Surname)=LOWER(?)');
    $s->execute([$name]);
    $r = $s->fetch(); return $r ? (int)$r[0] : null;
}

function _resolve_occupation(PDO $db, string $name): ?int {
    if (!$name) return null;
    $s = $db->prepare('SELECT OccupationID FROM Occupation WHERE LOWER(OccupationName)=LOWER(?)');
    $s->execute([$name]);
    $r = $s->fetch(); return $r ? (int)$r[0] : null;
}

function _parse_active(?string $v): bool {
    if (!$v) return true;
    return in_array(strtolower(trim($v)), ['1','true','yes','active']);
}

function import_preview_handler(): void {
    require_admin();

    if (empty($_FILES['file'])) json_out(['error' => 'No file uploaded'], 400);
    $file = $_FILES['file']['tmp_name'];
    if (!$file || !file_exists($file)) json_out(['error' => 'File upload failed'], 400);

    $handle = fopen($file, 'r');
    if (!$handle) json_out(['error' => 'Could not read file'], 500);

    // Detect BOM
    $bom = fread($handle, 3);
    if ($bom !== "\xEF\xBB\xBF") rewind($handle);

    $raw_headers = fgetcsv($handle);
    if (!$raw_headers) json_out(['error' => 'Empty or invalid CSV'], 400);

    $map = _map_headers($raw_headers);
    $db  = get_db();

    $results  = ['new' => [], 'update' => [], 'skip' => [], 'error' => []];
    $preview  = [];
    $row_num  = 1;

    while (($row = fgetcsv($handle)) !== false) {
        $row_num++;
        if (array_filter($row) === []) continue; // blank line

        $first = _col($map['firstName']  ?? null, $row);
        $last  = _col($map['lastName']   ?? null, $row);
        if (!$first && !$last) continue;

        $email   = _col($map['email']       ?? null, $row) ?: null;
        $phone   = _col($map['phoneNumber'] ?? null, $row) ?: null;
        $home    = _col($map['homePhone']   ?? null, $row) ?: null;
        $cell    = _col($map['cellPhone']   ?? null, $row) ?: null;
        $dob     = _parse_csv_date(_col($map['dateOfBirth'] ?? null, $row));

        $existing_id = _find_duplicate($db, $first, $last, $email, $phone ?? $home ?? $cell, $dob);

        $record = [
            'row'          => $row_num,
            'firstName'    => $first,
            'lastName'     => $last,
            'email'        => ($email && $email !== LIBRARY_EMAIL) ? $email : null,
            'phoneNumber'  => $phone,
            'homePhone'    => $home,
            'cellPhone'    => $cell,
            'dateOfBirth'  => $dob,
            'placeOfBirth' => _col($map['placeOfBirth'] ?? null, $row) ?: null,
            'dateJoined'   => _parse_csv_date(_col($map['dateJoined'] ?? null, $row)),
            'dateEnded'    => _parse_csv_date(_col($map['dateEnded']  ?? null, $row)),
            'category'     => _col($map['category']    ?? null, $row) ?: null,
            'county'       => _col($map['county']      ?? null, $row) ?: null,
            'irishSurname' => _col($map['irishSurname'] ?? null, $row) ?: null,
            'connectionType'=> _col($map['connectionType'] ?? null, $row) ?: 'Paternal',
            'occupation'   => _col($map['occupation']  ?? null, $row) ?: null,
            'notes'        => _col($map['notes']       ?? null, $row) ?: null,
            'isActive'     => _parse_active(_col($map['isActive'] ?? null, $row)),
            'approvedBy'   => _col($map['approvedBy']  ?? null, $row) ?: null,
            'signedBy'     => _col($map['signedBy']    ?? null, $row) ?: null,
            'proposer'     => _col($map['proposer']    ?? null, $row) ?: null,
            'seconder'     => _col($map['seconder']    ?? null, $row) ?: null,
            'otherSocieties' => _col($map['otherSocieties'] ?? null, $row) ?: null,
            'existingId'   => $existing_id,
        ];

        if ($existing_id) {
            $record['action'] = 'update';
            $results['update'][] = "$first $last (ID: $existing_id)";
        } else {
            $record['action'] = 'new';
            $results['new'][] = "$first $last";
        }
        $preview[] = $record;
    }
    fclose($handle);

    $_SESSION['import_preview'] = $preview;

    json_out([
        'preview' => $preview,
        'summary' => [
            'new'    => count($results['new']),
            'update' => count($results['update']),
            'total'  => count($preview),
        ],
    ]);
}

function import_confirm_handler(): void {
    require_admin();

    $preview = $_SESSION['import_preview'] ?? null;
    if (!$preview) json_out(['error' => 'No import preview found. Upload and preview the file first.'], 400);

    $db      = get_db();
    $created = 0;
    $updated = 0;
    $errors  = [];

    foreach ($preview as $rec) {
        try {
            $cat_id  = _resolve_category($db, $rec['category'] ?? '');
            $occ_id  = _resolve_occupation($db, $rec['occupation'] ?? '');
            $is_active = $rec['isActive'];

            // Derive IsActive from category if available
            if ($cat_id) {
                $s = $db->prepare('SELECT CategoryName FROM MemberCategory WHERE CategoryID=?');
                $s->execute([$cat_id]);
                $cat = $s->fetch();
                if ($cat) $is_active = in_array(strtolower($cat[0]), ['active','honorary']);
            }

            $email = ($rec['email'] && $rec['email'] !== LIBRARY_EMAIL) ? $rec['email'] : null;

            if ($rec['action'] === 'update' && $rec['existingId']) {
                $mid = $rec['existingId'];
                $sets = [];
                $vals = [];
                if ($rec['firstName'])  { $sets[] = 'FirstName=?';   $vals[] = $rec['firstName']; }
                if ($rec['lastName'])   { $sets[] = 'LastName=?';    $vals[] = $rec['lastName']; }
                if ($email)             { $sets[] = 'Email=?';       $vals[] = $email; }
                if ($rec['phoneNumber']){ $sets[] = 'PhoneNumber=?'; $vals[] = $rec['phoneNumber']; }
                if ($rec['dateOfBirth']){ $sets[] = '`Date of Birth`=?'; $vals[] = $rec['dateOfBirth']; }
                if ($rec['dateJoined']) { $sets[] = 'DateJoined=?';  $vals[] = $rec['dateJoined']; }
                if ($rec['dateEnded'])  { $sets[] = 'DateEnded=?';   $vals[] = $rec['dateEnded']; }
                if ($cat_id)            { $sets[] = 'MemberCategoryID=?'; $vals[] = $cat_id; }
                if ($occ_id)            { $sets[] = 'OccupationID=?'; $vals[] = $occ_id; }
                if ($rec['notes'])      { $sets[] = 'Notes=?';       $vals[] = $rec['notes']; }
                if ($rec['approvedBy']) { $sets[] = 'ApprovedBy=?';  $vals[] = $rec['approvedBy']; }
                if ($rec['signedBy'])   { $sets[] = 'SignedBy=?';    $vals[] = $rec['signedBy']; }
                if ($rec['proposer'])   { $sets[] = 'Proposer=?';    $vals[] = $rec['proposer']; }
                if ($rec['seconder'])   { $sets[] = 'Seconder=?';    $vals[] = $rec['seconder']; }
                $sets[] = 'IsActive=?'; $vals[] = $is_active ? 1 : 0;
                $vals[] = $mid;
                if ($sets) $db->prepare('UPDATE Members SET ' . implode(',', $sets) . ' WHERE MemberID=?')->execute($vals);
                $updated++;
            } else {
                $db->prepare('
                    INSERT INTO Members (FirstName, LastName, Email, PhoneNumber, `Date of Birth`,
                        `Place of Birth`, MemberCategoryID, OccupationID, IsActive, Notes,
                        DateJoined, DateEnded, ApprovedBy, SignedBy, Proposer, Seconder, OtherSocieties, CreatedAt)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())
                ')->execute([
                    $rec['firstName'], $rec['lastName'],
                    $email, $rec['phoneNumber'] ?? null,
                    $rec['dateOfBirth'] ?? null, $rec['placeOfBirth'] ?? null,
                    $cat_id, $occ_id, $is_active ? 1 : 0,
                    $rec['notes'] ?? null,
                    $rec['dateJoined'] ?? null, $rec['dateEnded'] ?? null,
                    $rec['approvedBy'] ?? null, $rec['signedBy'] ?? null,
                    $rec['proposer'] ?? null, $rec['seconder'] ?? null,
                    $rec['otherSocieties'] ?? null,
                ]);
                $mid = (int)$db->lastInsertId();
                $created++;
            }

            // Irish connections
            if ($mid && ($rec['county'] ?? '')) {
                $county_id = _resolve_county($db, $rec['county']);
                if ($county_id) {
                    $conn_type = $rec['connectionType'] ?? 'Paternal';
                    // Remove existing county connection for this type and re-insert
                    $db->prepare('DELETE FROM IrishConnectionByCounty WHERE MemberID=? AND ConnectionType=?')->execute([$mid, $conn_type]);
                    $db->prepare('INSERT INTO IrishConnectionByCounty (MemberID, CountyID, ConnectionType) VALUES (?,?,?)')->execute([$mid, $county_id, $conn_type]);
                }
            }
            if ($mid && ($rec['irishSurname'] ?? '')) {
                $surname_id = _resolve_surname($db, $rec['irishSurname']);
                if ($surname_id) {
                    $conn_type = $rec['connectionType'] ?? 'Paternal';
                    $db->prepare('DELETE FROM IrishConnectionBySurname WHERE MemberID=? AND ConnectionType=?')->execute([$mid, $conn_type]);
                    $db->prepare('INSERT INTO IrishConnectionBySurname (MemberID, SurnameID, ConnectionType) VALUES (?,?,?)')->execute([$mid, $surname_id, $conn_type]);
                }
            }

            // Additional phones
            foreach (['homePhone' => 'Home', 'cellPhone' => 'Cell'] as $field => $type) {
                if (!empty($rec[$field])) {
                    $s = $db->prepare('SELECT PhoneID FROM MemberPhoneNumbers WHERE MemberID=? AND PhoneType=?');
                    $s->execute([$mid, $type]);
                    if (!$s->fetch()) {
                        $db->prepare('INSERT INTO MemberPhoneNumbers (MemberID, PhoneType, PhoneNumber, IsPreferred) VALUES (?,?,?,0)')->execute([$mid, $type, $rec[$field]]);
                    }
                }
            }

        } catch (Exception $e) {
            $errors[] = "Row {$rec['row']}: " . $e->getMessage();
        }
    }

    unset($_SESSION['import_preview']);

    json_out([
        'success' => true,
        'created' => $created,
        'updated' => $updated,
        'errors'  => $errors,
    ]);
}

function import_template_handler(): void {
    require_admin();
    $headers = ['FirstName','LastName','Email','Phone','Home Phone','Cell Phone','DateOfBirth','PlaceOfBirth','DateJoined','DateEnded','Category','County','IrishSurname','ConnectionType','Occupation','Notes','IsActive','ApprovedBy','SignedBy','Proposer','Seconder','OtherSocieties'];
    _stream_csv('member_import_template.csv', $headers, [
        ['Jane','Doe','jane@example.com','','','','1970-01-15','Dublin','2010-06-01','','Active','Clare','Murphy','Paternal','Teacher','','true','','','','',''],
    ]);
}

// Borrow _stream_csv from export.php — only available if that file is loaded.
// Redefine locally if not already defined.
if (!function_exists('_stream_csv')) {
    function _stream_csv(string $filename, array $headers, array $rows): void {
        header('Content-Type: text/csv; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"$filename\"");
        $out = fopen('php://output', 'w');
        fputcsv($out, $headers);
        foreach ($rows as $row) fputcsv($out, $row);
        fclose($out);
        exit;
    }
}
