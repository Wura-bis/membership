<?php
$DEFAULT_SETTINGS = [
    'orgName'             => 'Benevolent Irish Society of PEI',
    'defaultAccess'       => 'public',
    'sessionTimeout'      => '60',
    'allowRegistration'   => 'true',
    'requireApproval'     => 'false',
    'maxMembers'          => '1000',
    'enableNotifications' => 'true',
    'enableAuditLog'      => 'true',
];

function get_settings_handler(): void {
    global $DEFAULT_SETTINGS;
    require_admin();
    $db  = get_db();
    $settings = $DEFAULT_SETTINGS;
    try {
        $rows = $db->query('SELECT SettingKey, SettingValue FROM Settings')->fetchAll();
        foreach ($rows as $r) $settings[$r[0]] = $r[1];
    } catch (Exception $e) {}
    json_out($settings);
}

function update_settings_handler(): void {
    require_admin();
    $data = get_body();
    if (!$data) json_out(['error' => 'No settings data'], 400);

    $db = get_db();
    foreach ($data as $key => $value) {
        $s = $db->prepare('SELECT SettingID FROM Settings WHERE SettingKey = ?');
        $s->execute([$key]);
        if ($s->fetch()) {
            $db->prepare('UPDATE Settings SET SettingValue = ? WHERE SettingKey = ?')->execute([$value, $key]);
        } else {
            $db->prepare('INSERT INTO Settings (SettingKey, SettingValue) VALUES (?,?)')->execute([$key, $value]);
        }
    }
    json_out(['success' => true]);
}

function update_single_setting_handler(string $key): void {
    require_admin();
    $data  = get_body();
    $value = $data['value'] ?? '';

    $db = get_db();
    $s  = $db->prepare('SELECT SettingID FROM Settings WHERE SettingKey = ?');
    $s->execute([$key]);
    if ($s->fetch()) {
        $db->prepare('UPDATE Settings SET SettingValue = ? WHERE SettingKey = ?')->execute([$value, $key]);
    } else {
        $db->prepare('INSERT INTO Settings (SettingKey, SettingValue) VALUES (?,?)')->execute([$key, $value]);
    }
    json_out(['success' => true]);
}
