<?php
function submit_support_handler(): void {
    $user = require_auth();
    $data = get_body();
    $subject = trim($data['subject'] ?? $data['title'] ?? '');
    $message = trim($data['message'] ?? $data['description'] ?? '');
    if (!$message) json_out(['error' => 'Message is required'], 400);

    $db = get_db();
    try {
        $db->prepare('INSERT INTO SupportTickets (UserID, Subject, Message, Status, CreatedAt) VALUES (?,?,?,\'open\',NOW())')
           ->execute([$user['id'], $subject, $message]);
        json_out(['success' => true], 201);
    } catch (Exception $e) {
        // Table may not exist yet
        json_out(['success' => true, 'note' => 'Logged'], 201);
    }
}

function get_support_handler(): void {
    require_admin();
    $db = get_db();
    try {
        $stmt = $db->query('SELECT t.TicketID, t.UserID, u.Username, t.Subject, t.Message, t.Status, t.AdminResponse, t.CreatedAt FROM SupportTickets t LEFT JOIN User u ON t.UserID = u.UserID ORDER BY t.CreatedAt DESC');
        $out  = [];
        foreach ($stmt->fetchAll() as $r) {
            $out[] = [
                'id'            => $r[0],
                'userId'        => $r[1],
                'username'      => $r[2],
                'subject'       => $r[3],
                'message'       => $r[4],
                'status'        => $r[5],
                'adminResponse' => $r[6],
                'createdAt'     => format_date($r[7]),
            ];
        }
        json_out($out);
    } catch (Exception $e) {
        json_out([]);
    }
}

function get_all_tickets_handler(): void { get_support_handler(); }

function get_my_tickets_handler(): void {
    $user = require_auth();
    $db   = get_db();
    try {
        $stmt = $db->prepare('SELECT TicketID, Subject, Message, Status, AdminResponse, CreatedAt FROM SupportTickets WHERE UserID = ? ORDER BY CreatedAt DESC');
        $stmt->execute([$user['id']]);
        $out = [];
        foreach ($stmt->fetchAll() as $r) {
            $out[] = ['id' => $r[0], 'subject' => $r[1], 'message' => $r[2], 'status' => $r[3], 'adminResponse' => $r[4], 'createdAt' => format_date($r[5])];
        }
        json_out($out);
    } catch (Exception $e) {
        json_out([]);
    }
}

function update_ticket_handler(int $ticket_id): void {
    require_admin();
    $data   = get_body();
    $status = $data['status']        ?? null;
    $resp   = $data['adminResponse'] ?? null;

    $db = get_db();
    $db->prepare('UPDATE SupportTickets SET Status = ?, AdminResponse = ? WHERE TicketID = ?')->execute([$status, $resp, $ticket_id]);
    json_out(['success' => true]);
}
