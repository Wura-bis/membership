<?php
const EXPORT_HEADERS = [
    'First Name','Last Name','Email',
    'Phone (Primary)','Phone (Cell)','Phone (Home)','Phone (Work)','Phone (Other)',
    'Place of Birth','Date of Birth','Occupation',
    'Irish County','Irish Surname','Irish Connection',
    'Current Street','Current City','Current Province','Current Country','Current Postal Code',
    'Category','Active','Date Joined','Date Ended','Application Date','Proposal Date','Approval Date',
    'Approved By','Signed By','Proposer','Seconder',
    'Other Societies','Roles','Notes',
];

function format_date(?string $d): string {
    return ($d && $d !== '0000-00-00') ? substr($d, 0, 10) : '';
}

function _stream_csv(string $filename, array $headers, array $rows): void {
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header('Pragma: no-cache');
    $out = fopen('php://output', 'w');
    fputcsv($out, $headers);
    foreach ($rows as $row) fputcsv($out, $row);
    fclose($out);
    exit;
}

function _optional_member_cols(PDO $db): array {
    $chk = $db->query("
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='Members'
          AND COLUMN_NAME IN ('ApplicationDate','ProposalDate','Approval Date')
    ");
    $found = [];
    foreach ($chk->fetchAll() as $c) $found[$c[0]] = true;
    return $found;
}

function _full_member_query(PDO $db, ?int $member_id = null): PDOStatement {
    $opt       = _optional_member_cols($db);
    $app_date  = !empty($opt['ApplicationDate']) ? 'm.ApplicationDate'   : 'NULL';
    $prop_date = !empty($opt['ProposalDate'])    ? 'm.ProposalDate'      : 'NULL';
    $appr_date = !empty($opt['Approval Date'])   ? 'm.`Approval Date`'   : 'NULL';

    $where = $member_id !== null ? 'WHERE m.MemberID = ?' : '';

    $sql = "
        SELECT
            m.FirstName, m.LastName, m.Email, m.PhoneNumber,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Cell' LIMIT 1) AS CellPhone,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Home' LIMIT 1) AS HomePhone,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Work' LIMIT 1) AS WorkPhone,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Other' LIMIT 1) AS OtherPhone,
            m.`Place of Birth`,
            m.`Date of Birth`,
            o.OccupationName,
            (SELECT GROUP_CONCAT(ic.CountyName ORDER BY ic.CountyName SEPARATOR '; ')
             FROM IrishConnectionByCounty icc
             JOIN IrishCounties ic ON icc.CountyID=ic.CountyID
             WHERE icc.MemberID=m.MemberID) AS IrishCounties,
            (SELECT GROUP_CONCAT(isur.Surname ORDER BY isur.Surname SEPARATOR '; ')
             FROM IrishConnectionBySurname ics
             JOIN IrishSurnames isur ON ics.SurnameID=isur.SurnameID
             WHERE ics.MemberID=m.MemberID) AS IrishSurnames,
            (SELECT GROUP_CONCAT(COALESCE(NULLIF(TRIM(icc2.ConnectionType),''),'Paternal') ORDER BY icc2.ID SEPARATOR '; ')
             FROM IrishConnectionByCounty icc2
             WHERE icc2.MemberID=m.MemberID) AS ConnectionTypes,
            ma.Street, ma.City,
            COALESCE(p.ProvinceName, ma.ProvinceID) AS Province,
            ma.CountryID AS Country,
            ma.PostalCode,
            mc.CategoryName,
            CASE WHEN m.IsActive=1 THEN 'Active' ELSE 'Inactive' END AS Active,
            m.DateJoined,
            m.DateEnded,
            $app_date  AS ApplicationDate,
            $prop_date AS ProposalDate,
            $appr_date AS ApprovalDate,
            m.ApprovedBy, m.SignedBy, m.Proposer, m.Seconder,
            m.OtherSocieties,
            (SELECT GROUP_CONCAT(r.RoleName ORDER BY r.RoleName SEPARATOR '; ')
             FROM MemberRole mr
             JOIN Role r ON mr.RoleID=r.RoleID
             WHERE mr.MemberID=m.MemberID) AS Roles,
            m.Notes
        FROM Members m
        LEFT JOIN MemberCategory mc ON m.MemberCategoryID=mc.CategoryID
        LEFT JOIN Occupation o ON m.OccupationID=o.OccupationID
        LEFT JOIN MemberAddress ma ON m.MemberID=ma.MemberID AND ma.IsCurrent=1
        LEFT JOIN Provinces p ON ma.ProvinceID=p.ProvinceID
        $where
        ORDER BY m.LastName, m.FirstName
    ";

    $stmt = $db->prepare($sql);
    if ($member_id !== null) $stmt->execute([$member_id]);
    else $stmt->execute();
    return $stmt;
}

function _row_to_csv(array $r): array {
    // Indices 0-32 match EXPORT_HEADERS exactly (33 columns)
    return [
        $r[0]  ?? '',                          // First Name
        $r[1]  ?? '',                          // Last Name
        $r[2]  ?? '',                          // Email
        $r[3]  ?? '',                          // Phone Primary
        $r[4]  ?? '',                          // Phone Cell
        $r[5]  ?? '',                          // Phone Home
        $r[6]  ?? '',                          // Phone Work
        $r[7]  ?? '',                          // Phone Other
        $r[8]  ?? '',                          // Place of Birth
        format_date($r[9]  ?? ''),             // Date of Birth
        $r[10] ?? '',                          // Occupation
        $r[11] ?? '',                          // Irish County
        $r[12] ?? '',                          // Irish Surname
        $r[13] ?? '',                          // Irish Connection
        $r[14] ?? '',                          // Street
        $r[15] ?? '',                          // City
        $r[16] ?? '',                          // Province
        $r[17] ?? '',                          // Country
        $r[18] ?? '',                          // Postal Code
        $r[19] ?? '',                          // Category
        $r[20] ?? '',                          // Active
        format_date($r[21] ?? ''),             // Date Joined
        format_date($r[22] ?? ''),             // Date Ended
        format_date($r[23] ?? ''),             // Application Date
        format_date($r[24] ?? ''),             // Proposal Date
        format_date($r[25] ?? ''),             // Approval Date
        $r[26] ?? '',                          // Approved By
        $r[27] ?? '',                          // Signed By
        $r[28] ?? '',                          // Proposer
        $r[29] ?? '',                          // Seconder
        $r[30] ?? '',                          // Other Societies
        $r[31] ?? '',                          // Roles
        $r[32] ?? '',                          // Notes
    ];
}

function export_all_members_csv(): void {
    require_private_or_admin();
    $db   = get_db();
    $stmt = _full_member_query($db);
    $rows = [];
    foreach ($stmt->fetchAll() as $r) $rows[] = _row_to_csv($r);
    _stream_csv('members.csv', EXPORT_HEADERS, $rows);
}

function _parse_export_ids(): array {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $body = get_body();
        $ids  = $body['ids'] ?? [];
    } else {
        $ids = $_GET['ids'] ?? [];
    }
    if (is_string($ids)) {
        $ids = explode(',', $ids);
    }
    return array_filter(array_map('intval', (array)$ids), fn($id) => $id > 0);
}

function export_selected_members_csv(?string $ids_param = null): void {
    require_private_or_admin();
    
    // Parse comma-separated IDs or JSON body
    $ids = $ids_param !== null ? array_filter(array_map('intval', explode(',', $ids_param)), fn($id) => $id > 0) : _parse_export_ids();
    if (empty($ids)) {
        http_response_code(400);
        echo 'No valid member IDs provided';
        exit;
    }
    
    try {
        $db = get_db();
        $opt       = _optional_member_cols($db);
        $app_date  = !empty($opt['ApplicationDate']) ? 'm.ApplicationDate'   : 'NULL';
        $prop_date = !empty($opt['ProposalDate'])    ? 'm.ProposalDate'      : 'NULL';
        $appr_date = !empty($opt['Approval Date'])   ? 'm.`Approval Date`'   : 'NULL';

    // Build IN clause with placeholders
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    
    $sql = "
        SELECT
            m.FirstName, m.LastName, m.Email, m.PhoneNumber,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Cell' LIMIT 1) AS CellPhone,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Home' LIMIT 1) AS HomePhone,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Work' LIMIT 1) AS WorkPhone,
            (SELECT mpn.PhoneNumber FROM MemberPhoneNumbers mpn
             WHERE mpn.MemberID=m.MemberID AND mpn.PhoneType='Other' LIMIT 1) AS OtherPhone,
            m.`Place of Birth`,
            m.`Date of Birth`,
            o.OccupationName,
            (SELECT GROUP_CONCAT(ic.CountyName ORDER BY ic.CountyName SEPARATOR '; ')
             FROM IrishConnectionByCounty icc
             JOIN IrishCounties ic ON icc.CountyID=ic.CountyID
             WHERE icc.MemberID=m.MemberID) AS IrishCounties,
            (SELECT GROUP_CONCAT(isur.Surname ORDER BY isur.Surname SEPARATOR '; ')
             FROM IrishConnectionBySurname ics
             JOIN IrishSurnames isur ON ics.SurnameID=isur.SurnameID
             WHERE ics.MemberID=m.MemberID) AS IrishSurnames,
            (SELECT GROUP_CONCAT(COALESCE(NULLIF(TRIM(icc2.ConnectionType),''),'Paternal') ORDER BY icc2.ID SEPARATOR '; ')
             FROM IrishConnectionByCounty icc2
             WHERE icc2.MemberID=m.MemberID) AS ConnectionTypes,
            ma.Street, ma.City,
            COALESCE(p.ProvinceName, ma.ProvinceID) AS Province,
            ma.CountryID AS Country,
            ma.PostalCode,
            mc.CategoryName,
            CASE WHEN m.IsActive=1 THEN 'Active' ELSE 'Inactive' END AS Active,
            m.DateJoined,
            m.DateEnded,
            $app_date  AS ApplicationDate,
            $prop_date AS ProposalDate,
            $appr_date AS ApprovalDate,
            m.ApprovedBy, m.SignedBy, m.Proposer, m.Seconder,
            m.OtherSocieties,
            (SELECT GROUP_CONCAT(r.RoleName ORDER BY r.RoleName SEPARATOR '; ')
             FROM MemberRole mr
             JOIN Role r ON mr.RoleID=r.RoleID
             WHERE mr.MemberID=m.MemberID) AS Roles,
            m.Notes
        FROM Members m
        LEFT JOIN MemberCategory mc ON m.MemberCategoryID=mc.CategoryID
        LEFT JOIN Occupation o ON m.OccupationID=o.OccupationID
        LEFT JOIN MemberAddress ma ON m.MemberID=ma.MemberID AND ma.IsCurrent=1
        LEFT JOIN Provinces p ON ma.ProvinceID=p.ProvinceID
        WHERE m.MemberID IN ($placeholders)
        ORDER BY m.LastName, m.FirstName
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute($ids);
    $rows = [];
    foreach ($stmt->fetchAll() as $r) $rows[] = _row_to_csv($r);
    _stream_csv('members_export.csv', EXPORT_HEADERS, $rows);
    } catch (Exception $e) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Export error: ' . $e->getMessage();
        exit;
    }
}

function export_member_csv(int $member_id): void {
    require_private_or_admin();
    $db   = get_db();
    $stmt = _full_member_query($db, $member_id);
    $m    = $stmt->fetch();
    if (!$m) { http_response_code(404); echo 'Not found'; exit; }
    $row  = _row_to_csv($m);
    $rows = [];
    foreach (EXPORT_HEADERS as $i => $label) $rows[] = [$label, $row[$i] ?? ''];
    _stream_csv("member_{$member_id}.csv", ['Field', 'Value'], $rows);
}

function export_member_pdf(int $member_id): void {
    require_private_or_admin();
    $db   = get_db();
    $stmt = _full_member_query($db, $member_id);
    $m    = $stmt->fetch();
    if (!$m) { http_response_code(404); echo 'Not found'; exit; }
    $row  = _row_to_csv($m);
    $name = htmlspecialchars(trim(($m[0] ?? '') . ' ' . ($m[1] ?? '')));

    header('Content-Type: text/html; charset=utf-8');
    echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>$name</title>
    <style>
        body{font-family:Arial,sans-serif;margin:40px;font-size:13px}
        h1{color:#0f766e;margin-bottom:4px}
        h2{color:#0f766e;margin-bottom:16px;font-size:16px}
        table{border-collapse:collapse;width:100%}
        td,th{border:1px solid #ccc;padding:7px 12px;vertical-align:top}
        th{background:#f0fdfa;text-align:left;width:32%;font-weight:600}
        @media print{body{margin:10px}}
    </style></head><body>
    <h1>BIS Member Profile</h1><h2>$name</h2><table>";

    foreach (EXPORT_HEADERS as $i => $label) {
        $v = htmlspecialchars((string)($row[$i] ?? ''));
        if ($v === '') continue;
        echo "<tr><th>$label</th><td>$v</td></tr>";
    }

    echo '</table><script>window.print()</script></body></html>';
    exit;
}

function export_all_members_pdf(): void {
    export_all_members_csv();
}

function export_fiscal_year_csv(): void {
    require_private_or_admin();
    $fy = $_GET['fiscalYear'] ?? '';
    $db = get_db();

    $sql = '
        SELECT DISTINCT m.MemberID, m.FirstName, m.LastName, mc.CategoryName,
               m.DateJoined, m.IsActive, r.RoleName, fy.YearLabel
        FROM Members m
        LEFT JOIN MemberCategory mc ON m.MemberCategoryID = mc.CategoryID
        LEFT JOIN MemberRole mr ON m.MemberID = mr.MemberID
        LEFT JOIN Role r ON mr.RoleID = r.RoleID
        LEFT JOIN FiscalYear fy ON mr.FiscalYearID = fy.FiscalYearID
    ';
    $params = [];
    if ($fy) { $sql .= ' WHERE fy.YearLabel = ?'; $params[] = $fy; }
    $sql .= ' ORDER BY m.LastName, m.FirstName';

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = [];
    foreach ($stmt->fetchAll() as $r) {
        $rows[] = [$r[0], $r[1], $r[2], $r[3] ?? '', format_date($r[4] ?? ''), $r[5] == 1 ? 'Active' : 'Inactive', $r[6] ?? '', $r[7] ?? ''];
    }
    _stream_csv('members_fiscal_year.csv', ['ID','First Name','Last Name','Category','Date Joined','Status','Role','Fiscal Year'], $rows);
}

function export_recognitions_csv(): void {
    require_private_or_admin();
    $db   = get_db();
    $stmt = $db->query('
        SELECT mr.RecognitionID, m.FirstName, m.LastName, rt.Name, mr.Notes
        FROM MemberRecognitions mr
        LEFT JOIN Members m ON mr.MemberID = m.MemberID
        LEFT JOIN RecognitionTypes rt ON mr.RecognitionTypeID = rt.RecognitionTypeID
        WHERE mr.IsActive = 1
        ORDER BY m.LastName, m.FirstName
    ');
    $rows = [];
    foreach ($stmt->fetchAll() as $r) $rows[] = [$r[0], $r[1], $r[2], $r[3] ?? '', $r[4] ?? ''];
    _stream_csv('recognitions.csv', ['ID','First Name','Last Name','Recognition','Notes'], $rows);
}
